<?php



$fast_plano_default = "0";





$nome_loja = "SISTEMA SAAS"; // Adicionei um ponto e vírgula aqui

// DOMÍNIO

// ALTERE O "teste.com" PARA O DOMÍNIO COMPRADO POR VOCÊ

$dominio = "digitavitrine.com.br";



// Número de WhatsApp

$numero_whatsapp = "555555555555";



// Comissionamento

$valor_comissionamento = 0;



//Troque por seus dados do seu banco de dados

$fast_db_host = "localhost";

$fast_db_user = "tecautov_sistema";

$fast_db_pass = "hevRQ6#Ur]6R";

$fast_db_name = "tecautov_sistema";





//E-mail SMTP

$fast_smtp_user = "suporte@digitavitrine.com.br";

$fast_smtp_pass = "4fdf1ewB2A5H";

$fast_smtp_host = "mail.digitavitrine.com.br";~

$fast_smtp_port = "465";

$fast_smtp_secure = "ssl";





$fast_external_token = ""; // Adicione seu token aqui entre vírgula e  ponto



$fast_recaptcha_sitekey = "6LfTGy0rAAAAAG3peUT1GGAMWoYqw5sVbpDSjrD0";

$fast_recaptcha_secretkey = "6LfTGy0rAAAAALxkjqVvsVLk_yBAd-iV6S4zmMn1";



$fast_mp_public_key = "";

$fast_mp_acess_token = "";

$fast_mp_client_id = "";

$fast_mp_client_secret = "";



?>