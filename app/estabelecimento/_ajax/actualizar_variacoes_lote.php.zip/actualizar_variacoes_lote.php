<?php
include('../../../_core/_includes/config.php');
header('Content-Type: application/json');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Função para log simplificado (opcional, pode ser removida em produção)
function log_variantes($msg) {
    // Descomente a linha abaixo para logs de debug se necessário
    // file_put_contents(__DIR__ . '/variantes.log', "[" . date('Y-m-d H:i:s') . "] $msg\n", FILE_APPEND);
}

try {
    $input = json_decode(file_get_contents("php://input"), true);

    if (!isset($input['produto_id'], $input['variacoes'], $input['quantidade'])) {
        throw new Exception("Dados incompletos.");
    }

    $produto_id = mysqli_real_escape_string($db_con, $input['produto_id']);
    $quantidade = intval($input['quantidade']);
    $variacoesSelecionadas = $input['variacoes'];

    if ($quantidade <= 0) throw new Exception("Quantidade inválida: $quantidade");

    log_variantes("Atualizando estoque - Produto: $produto_id, Quantidade: $quantidade");

    $query = mysqli_query($db_con, "SELECT variacao FROM produtos WHERE id = '$produto_id'");
    if (!$query || !mysqli_num_rows($query)) throw new Exception("Produto não encontrado: $produto_id");

    $row = mysqli_fetch_array($query);
    $variacoes = json_decode($row['variacao'], true);

    $atualizacoes_realizadas = 0;

    foreach ($variacoesSelecionadas as $grupo => $itens) {
        if (!isset($variacoes[$grupo]['item'])) {
            continue;
        }

        foreach ($itens as $item) {
            $itemIndex = $item['item'];
            
            foreach ($variacoes[$grupo]['item'] as $key => &$varItem) {
                if ((string)$key === (string)$itemIndex) {
                    // Verificar se quantidade existe, se não criar com valor padrão
                    if (!isset($varItem['quantidade']) || empty($varItem['quantidade'])) {
                        $varItem['quantidade'] = base64_encode("10");
                    }
                    
                    // Decodificar quantidade atual
                    $qtd_atual = intval(base64_decode($varItem['quantidade']));
                    
                    // Verificar se há estoque suficiente e calcular nova quantidade
                    if ($qtd_atual < $quantidade) {
                        // Não permitir estoque negativo
                        $qtd_nova = 0;
                        log_variantes("Estoque insuficiente: Grupo $grupo, Item $key ($qtd_atual < $quantidade)");
                    } else {
                        $qtd_nova = $qtd_atual - $quantidade;
                    }
                    
                    // Salvar nova quantidade
                    $varItem['quantidade'] = base64_encode((string)$qtd_nova);
                    $atualizacoes_realizadas++;
                    
                    log_variantes("Atualizado: Grupo $grupo, Item $key, $qtd_atual ➝ $qtd_nova");
                    break;
                }
            }
        }
    }

    // Salvar as alterações no banco de dados
    $novo_json = mysqli_real_escape_string($db_con, json_encode($variacoes));
    $update = mysqli_query($db_con, "UPDATE produtos SET variacao = '$novo_json' WHERE id = '$produto_id'");

    if (!$update) {
        throw new Exception("Falha ao atualizar banco de dados: " . mysqli_error($db_con));
    }
    
    log_variantes("Sucesso: $atualizacoes_realizadas variações atualizadas");
    echo json_encode(['status' => 'success', 'atualizacoes' => $atualizacoes_realizadas]);
    
} catch (Throwable $e) {
    log_variantes("Erro: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
