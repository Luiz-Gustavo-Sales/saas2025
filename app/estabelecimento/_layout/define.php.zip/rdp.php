<div class="footer">

	<div class="footer-info">

		<div class="container">

			<div class="row">

				<div class="col-md-12">

					<span><?php echo $app['endereco_completo']; ?></span>

				</div>

			</div>

			<div class="row">

				<div class="col-md-12">

					<div class="social">
						<?php if( $app['contato_whatsapp'] ) { ?>
						<a href="https://wa.me/55<?php echo $app['contato_whatsapp']; ?>" target="_blank"><i class="lni lni-whatsapp"></i></a>
						<?php } ?>
						<?php if( $app['contato_facebook'] ) { ?>
						<a href="<?php echo linker( $app['contato_facebook'] ); ?>" target="_blank"><i class="lni lni-facebook-filled"></i></a>
						<?php } ?>
						<?php if( $app['contato_instagram'] ) { ?>
						<a href="<?php echo linker( $app['contato_instagram'] ); ?>" target="_blank"><i class="lni lni-instagram-original"></i></a>
						<?php } ?>
						<?php if( $app['contato_youtube'] ) { ?>
						<a href="<?php echo linker( $app['contato_youtube'] ); ?>" target="_blank"><i class="lni lni-map-marker"></i></a>
						<?php } ?>
					</div>

				</div>

			</div>

		</div>

	</div>

	<div class="copyright">

		<div class="container">

			<div class="row">

				<div class="col-md-12">

					<a class="watermark" href="https://<?php global $simple_url; echo $simple_url; ?>/conheca/" target="_blank">
						<img 
							src="<?php echo $app['url']; ?>/_core/_cdn/img/logo.png" 
							alt="Logo"
							style="max-height: 40px; display: block; margin: 0 auto; margin-bottom: 0; padding: 0;" />
					</a>

				</div>

			</div>

		</div>

	</div>

</div>