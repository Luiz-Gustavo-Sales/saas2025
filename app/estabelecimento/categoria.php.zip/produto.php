<?php
// CORE
include($virtualpath.'/_layout/define.php');
//URL
$pegaurl =  "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
// APP
global $app;
is_active( $app['id'] );
global $inparametro;
$back_button = "true";
// Querys
$app_id = $app['id'];
$produto = $inparametro;
// Has content
$query_content = mysqli_query( $db_con, "SELECT * FROM produtos WHERE rel_estabelecimentos_id = '$app_id' AND id = '$produto' AND status = '1' ORDER BY id ASC LIMIT 1" );
$data_content = mysqli_fetch_array( $query_content );
$has_content = mysqli_num_rows( $query_content );

// Buscar dados do link de afiliado
$link_afiliado_data = get_link_afiliado($produto, $app_id);
// SEO
$seo_subtitle = $app['title']." - ".$data_content['nome'];
$seo_description = $data_content['descricao'];
$seo_keywords = $app['title'].", ".$seo_title.", ".$data_content['nome'];
$seo_image = thumber( $data_content['destaque'], 400 );
// HEADER
$system_header .= "";
include($virtualpath.'/_layout/head.php');
include($virtualpath.'/_layout/top.php');
include($virtualpath.'/_layout/sidebars.php');
include($virtualpath.'/_layout/modal.php');
instantrender();

// Função para ajustar brilho das cores
function adjust_brightness($hex, $percent) {
    if (!$hex) return '#2c3e50';
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + ($r * $percent / 100)));
    $g = max(0, min(255, $g + ($g * $percent / 100)));
    $b = max(0, min(255, $b + ($b * $percent / 100)));
    
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}

if (isset($_POST['quantidade_para_remover'])) {
    $quantidade_para_remover = $_POST['quantidade_para_remover'];
    $remove_query = mysqli_query($db_con, "UPDATE `produtos` SET `posicao` = `posicao` - '$quantidade_para_remover' WHERE `id` = '$produto'");
}
?>

<style>
/* ================================================ */
/* DESIGN MODERNO PARA PÁGINA DE PRODUTO */
/* ================================================ */

/* Variáveis CSS dinâmicas baseadas na cor do estabelecimento */
:root {
    --primary-color: <?php echo $app['cor'] ?: '#2c3e50'; ?>;
    --secondary-color: <?php echo adjust_brightness($app['cor'] ?: '#2c3e50', -30); ?>;
    --accent-color: <?php echo adjust_brightness($app['cor'] ?: '#2c3e50', 20); ?>;
    --success-color: #27ae60;
    --danger-color: #e74c3c;
    --warning-color: #f39c12;
    --light-gray: #f8f9fa;
    --medium-gray: #e9ecef;
    --dark-gray: #495057;
    --white: #ffffff;
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.12);
    --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
    --border-radius: 16px;
    --border-radius-sm: 8px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    --gradient-primary: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    --gradient-bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* ================================================ */
/* CORREÇÃO DAS CORES DA BARRA SUPERIOR (MINITOP) */
/* ================================================ */

/* Barra superior com cor dinâmica do estabelecimento */
.minitop {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    padding: 12px 0 !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important;
}

/* Info badges da barra superior com texto branco */
.info-badges-desktop .info-badge {
    background: rgba(255,255,255,0.15) !important;
    color: var(--white) !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    padding: 6px 12px !important;
    margin-right: 12px !important;
    transition: var(--transition) !important;
    backdrop-filter: blur(10px) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
}

.info-badges-desktop .info-badge:hover {
    background: rgba(255,255,255,0.25) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2) !important;
}

.info-badges-desktop .info-badge i {
    color: var(--white) !important;
    margin-right: 6px !important;
    font-weight: bold !important;
    opacity: 0.9 !important;
}

.info-badges-desktop .info-badge span {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

/* Status de funcionamento */
.funcionamento {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.funcionamento .aberto {
    color: #4CAF50 !important;
    background: rgba(76,175,80,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(76,175,80,0.3) !important;
}

.funcionamento .fechado {
    color: #f44336 !important;
    background: rgba(244,67,54,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(244,67,54,0.3) !important;
}

.funcionamento i {
    margin-right: 6px !important;
    font-weight: bold !important;
}

/* Reset e configurações base - APENAS para a área do produto */
.single-produto * {
    box-sizing: border-box;
}

/* Configurações básicas sem afetar o header */
body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: var(--dark-gray);
    background: #ffffff;
}

/* Garantir que tudo fique dentro da viewport no mobile - APENAS para conteúdo do produto */
@media (max-width: 768px) {
    .single-produto * {
        max-width: 100% !important;
        box-sizing: border-box !important;
    }
    
    .single-produto {
        overflow-x: hidden !important;
        width: 100% !important;
    }
}

/* Container ponta a ponta - APENAS para a área do produto */
.single-produto .container.nopaddmobile {
    max-width: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
}

.single-produto .middle {
    padding: 0;
    margin: 0;
    width: 100%;
}

/* Reset específico para rows e colunas do produto */
.single-produto .row {
    margin-left: 0 !important;
    margin-right: 0 !important;
}

.single-produto .col-md-12, .single-produto .col-md-5, .single-produto .col-md-7, 
.single-produto .col-md-3, .single-produto .col-md-9, .single-produto .col-md-6, 
.single-produto .col-md-10, .single-produto .col-md-2,
.single-produto .col-sm-12, .single-produto .col-sm-6, .single-produto .col-sm-10, 
.single-produto .col-sm-2, .single-produto .col-xs-12, .single-produto .col-xs-6, 
.single-produto .col-xs-10, .single-produto .col-xs-2 {
    padding-left: 0 !important;
    padding-right: 0 !important;
}

/* Header melhorado */
.header-interna {
    background: var(--white);
    box-shadow: var(--shadow-sm);
    margin: 0;
    width: 100%;
}

.locked-bar {
    padding: 15px 20px;
    background: var(--gradient-primary);
}

.holder-interna {
    padding: 0;
    margin: 0;
}

.avatar .holder {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
    border: 3px solid var(--white);
    box-shadow: var(--shadow-md);
    transition: var(--transition);
}

.avatar .holder:hover {
    transform: scale(1.05);
    box-shadow: var(--shadow-lg);
}

.avatar .holder img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* Breadcrumb moderno */
.title-icon {
    margin: 20px;
    margin-bottom: 10px;
}

.title-icon span {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary-color);
    background: var(--white);
    padding: 15px 25px;
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
    display: inline-block;
}

.bread-box {
    background: var(--white);
    padding: 12px 20px;
    margin: 0 20px 20px 20px;
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
}

.bread {
    font-size: 14px;
    color: var(--dark-gray);
}

.bread a {
    color: var(--primary-color);
    text-decoration: none;
    transition: var(--transition);
}

.bread a:hover {
    color: var(--secondary-color);
    text-decoration: underline;
}

.bread span {
    margin: 0 8px;
    color: var(--medium-gray);
}

/* Container do produto */
.single-produto {
    background: var(--white);
    border-radius: 0;
    box-shadow: none;
    overflow: visible;
    margin: 0;
    width: 100%;
}

/* Galeria de imagens moderna */
.galeria {
    position: relative;
    background: #f8f9fa;
    border-radius: 0;
    overflow: hidden;
    margin: 0;
    width: 100%;
}

.carousel-inner {
    border-radius: var(--border-radius);
    overflow: hidden;
    height: 500px;
    background: #f8f9fa;
}

.item.zoomer {
    position: relative;
    transition: var(--transition);
    height: 500px;
    overflow: hidden;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Ampliar o conteúdo das imagens e vídeos para ocupar mais espaço */
.item.zoomer a {
    display: block;
    width: 100%;
    height: 100%;
    overflow: hidden;
}

.item.zoomer img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    transition: var(--transition);
    display: block !important;
    min-width: 100%;
    min-height: 100%;
    max-width: none;
    max-height: none;
    opacity: 1 !important;
    /* Escala maior para preencher melhor o espaço e tornar o conteúdo maior */
    transform: scale(1.3);
}

.item.zoomer:hover img {
    transform: scale(1.4); /* Aumenta ainda mais no hover */
}

.item.zoomer iframe {
    width: 100%;
    height: 100%;
    min-width: 100%;
    min-height: 100%;
    border: none;
    display: block !important;
    object-fit: cover;
    opacity: 1 !important;
    /* Escala maior para vídeos também */
    transform: scale(1.3);
}

/* Garantir que imagens em slides não ativos também sejam carregadas */
.carousel-inner .item {
    visibility: visible !important;
}

.carousel-inner .item img {
    visibility: visible !important;
    opacity: 1 !important;
}

/* Setas de navegação estilizadas */
.seta {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0,0,0,0.7) !important;
    border: none !important;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--white);
    font-size: 18px;
    transition: var(--transition);
    z-index: 1000;
    cursor: pointer;
    text-decoration: none;
}

.seta:hover {
    background: var(--primary-color) !important;
    transform: translateY(-50%) scale(1.1);
    color: var(--white) !important;
    text-decoration: none;
}

.seta-esquerda {
    left: 15px;
}

.seta-direita {
    right: 15px;
}

/* Garantir visibilidade das setas */
.carousel-control {
    width: 60px;
    opacity: 1;
    z-index: 1000;
}

.carousel-control.left,
.carousel-control.right {
    background: none;
    filter: none;
}

.carousel-control .glyphicon-chevron-left,
.carousel-control .glyphicon-chevron-right {
    font-size: 18px;
    color: white;
}

/* Melhorar visibilidade das imagens no carrossel */
.carousel-inner > .item {
    position: relative;
    display: none;
    -webkit-transition: 0.6s ease-in-out left;
    -o-transition: 0.6s ease-in-out left;
    transition: 0.6s ease-in-out left;
}

.carousel-inner > .item.active {
    display: block;
}

/* Garantir que todas as imagens sejam carregadas corretamente */
.carousel-inner .item img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* Garantir que o carrossel funcione corretamente */
.carousel-inner {
    position: relative;
    width: 100%;
    overflow: hidden;
}

/* Melhorar as bolinhas indicadoras */
.carousel-indicators {
    bottom: 10px;
    z-index: 1000;
}

.carousel-indicators li {
    background-color: rgba(255,255,255,0.5);
    border: 1px solid rgba(255,255,255,0.8);
}

.carousel-indicators .active {
    background-color: var(--primary-color);
    border: 1px solid var(--primary-color);
}

/* Seção azul com informações do produto */
.produto-info-header {
    background: var(--gradient-primary);
    padding: 25px;
    margin: 0;
    color: var(--white);
    border-radius: 0;
}

.produto-info-header .nome span {
    font-size: 28px;
    font-weight: 700;
    color: var(--white);
    display: block;
    margin-bottom: 20px;
    line-height: 1.3;
}

.produto-info-header .thelabel {
    font-weight: 600;
    color: rgba(255,255,255,0.9);
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 5px;
    display: block;
}

.produto-info-header .ref-info {
    margin-bottom: 15px;
}

.produto-info-header .ref-value {
    background: rgba(255,255,255,0.15);
    padding: 8px 15px;
    border-radius: var(--border-radius-sm);
    font-family: 'Monaco', 'Menlo', monospace;
    font-size: 13px;
    color: var(--white);
    border: 1px solid rgba(255,255,255,0.2);
    display: inline-block;
    margin-top: 5px;
}

.produto-info-header .preco-info {
    margin-bottom: 15px;
}

.produto-info-header .valor_anterior {
    font-size: 14px;
    color: rgba(255,255,255,0.7);
    margin-bottom: 5px;
}

.produto-info-header .valor_atual {
    font-size: 20px;
    font-weight: 700;
    color: var(--white);
    background: rgba(255,255,255,0.1);
    padding: 10px 15px;
    border-radius: var(--border-radius-sm);
    margin-top: 5px;
    border: 1px solid rgba(255,255,255,0.2);
}

.produto-info-header .estoque-info {
    margin-bottom: 15px;
}

.produto-info-header .estoque-quantidade {
    background: rgba(39, 174, 96, 0.8);
    padding: 8px 15px;
    border-radius: var(--border-radius-sm);
    font-weight: 600;
    margin-top: 5px;
    display: inline-block;
}

.produto-info-header .estoque-quantidade #em-estoque {
    font-size: 18px;
    font-weight: 700;
}

.produto-info-header .link-info {
    margin-bottom: 15px;
}

.produto-info-header .link-info .btn {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: var(--white);
    padding: 10px 20px;
    border-radius: var(--border-radius-sm);
    font-weight: 600;
    transition: var(--transition);
    margin-top: 5px;
}

.produto-info-header .link-info .btn:hover {
    background: rgba(255,255,255,0.3);
    border-color: rgba(255,255,255,0.5);
    transform: translateY(-1px);
}

.produto-info-header .detalhes-info {
    margin-bottom: 0;
}

.produto-info-header .descricao {
    background: rgba(255,255,255,0.1);
    padding: 15px;
    border-radius: var(--border-radius-sm);
    margin-top: 10px;
    border-left: 4px solid rgba(255,255,255,0.3);
}

.produto-info-header .descricao span {
    font-size: 15px;
    line-height: 1.6;
    color: rgba(255,255,255,0.95);
}

/* Responsividade para a seção azul */
@media (max-width: 768px) {
    .produto-info-header {
        padding: 20px 15px !important; /* Manter padding interno para legibilidade */
        margin: 0 !important; /* Remove margin lateral */
        border-radius: 0 !important; /* Remove border-radius para ocupar toda largura */
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    .produto-info-header .nome span {
        font-size: 22px;
        margin-bottom: 15px;
    }
    
    .produto-info-header .thelabel {
        font-size: 12px;
    }
    
    .produto-info-header .ref-value {
        font-size: 12px;
        padding: 6px 12px;
    }
    
    .produto-info-header .valor_atual {
        font-size: 18px;
        padding: 8px 12px;
    }
    
    .produto-info-header .estoque-quantidade {
        padding: 6px 12px;
        font-size: 14px;
    }
    
    .produto-info-header .estoque-quantidade #em-estoque {
        font-size: 16px;
    }
    
    .produto-info-header .link-info .btn {
        padding: 8px 16px;
        font-size: 13px;
    }
    
    .produto-info-header .descricao {
        padding: 12px;
    }
    
    .produto-info-header .descricao span {
        font-size: 14px;
    }
}

/* Detalhes do produto */
.produto-detalhes {
    padding: 20px;
    width: 100%;
}

.padd-container-mobile {
    padding: 10px;
}

@media (max-width: 768px) {
    .produto-detalhes {
        padding: 15px;
    }
    
    .padd-container-mobile {
        padding: 0 !important; /* Remove completamente o padding lateral */
        margin: 0 !important; /* Remove margin também */
    }
    
    .single-produto .col-md-6 {
        padding: 0 !important;
        margin-bottom: 15px;
    }
}

/* Nome do produto */
.nome span {
    font-size: 24px;
    font-weight: 700;
    color: var(--primary-color);
    display: block;
    margin-bottom: 20px;
    line-height: 1.3;
}

/* Labels modernos */
.thelabel {
    font-weight: 600;
    color: var(--dark-gray);
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
    display: block;
}

/* Referência do produto */
.ref span {
    background: var(--light-gray);
    padding: 8px 15px;
    border-radius: var(--border-radius-sm);
    font-family: 'Monaco', 'Menlo', monospace;
    font-size: 13px;
    color: var(--dark-gray);
    border: 1px solid var(--medium-gray);
}

/* Descrição do produto */
.descricao {
    background: var(--light-gray);
    padding: 20px;
    border-radius: var(--border-radius-sm);
    margin-bottom: 20px;
    border-left: 4px solid var(--primary-color);
}

.descricao span {
    font-size: 15px;
    line-height: 1.6;
    color: var(--dark-gray);
}

/* Preços modernos */
.valor_anterior {
    font-size: 14px;
    color: #999;
    margin-bottom: 5px;
}

.valor_anterior strike {
    opacity: 0.7;
}

.valor {
    font-size: 28px;
    font-weight: 700;
    color: var(--success-color);
    margin-bottom: 10px;
    display: block;
}

.apenas {
    font-size: 14px;
    color: var(--dark-gray);
    font-weight: 500;
    margin-bottom: 5px;
    display: block;
}

/* Botão WhatsApp estilizado */
.btn-success {
    background: var(--gradient-primary);
    border: none;
    padding: 12px 24px;
    border-radius: var(--border-radius-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: var(--transition);
    box-shadow: var(--shadow-sm);
}

.btn-success:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
    background: var(--secondary-color);
}

/* Formulário de compra */
.comprar {
    background: var(--light-gray);
    padding: 20px;
    border-radius: 0;
    margin: 0;
    border: none;
    border-top: 1px solid var(--medium-gray);
    width: 100%;
}

.line {
    margin-bottom: 25px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--medium-gray);
}

.line:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

/* Campo de quantidade moderno */
.campo-numero {
    display: flex;
    align-items: center;
    background: var(--white);
    border-radius: var(--border-radius-sm);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    border: 2px solid var(--medium-gray);
    max-width: 150px;
    margin-left: auto;
}

.campo-numero i {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--primary-color);
    color: var(--white);
    cursor: pointer;
    transition: var(--transition);
    font-size: 14px;
}

.campo-numero i:hover {
    background: var(--secondary-color);
    transform: scale(1.1);
}

.campo-numero input {
    border: none;
    width: 60px;
    height: 40px;
    text-align: center;
    font-weight: 600;
    font-size: 16px;
    background: var(--white);
    color: var(--dark-gray);
}

.campo-numero input:focus {
    outline: none;
    background: var(--light-gray);
}

/* Estoque display */
#em-estoque {
    background: var(--success-color);
    color: var(--white);
    padding: 8px 16px;
    border-radius: var(--border-radius-sm);
    font-weight: 600;
    display: inline-block;
    box-shadow: var(--shadow-sm);
}

/* Textarea de observações */
textarea {
    width: 100%;
    padding: 15px;
    border: 2px solid var(--medium-gray);
    border-radius: var(--border-radius-sm);
    font-family: inherit;
    font-size: 14px;
    line-height: 1.5;
    resize: vertical;
    transition: var(--transition);
    background: var(--white);
}

textarea:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(var(--primary-color), 0.1);
}

/* Variações de produto - Layout horizontal */
.line-variacao {
    background: var(--white);
    padding: 20px;
    border-radius: var(--border-radius-sm);
    border: 2px solid var(--medium-gray);
    margin-bottom: 20px;
    width: 100%;
}

.line-variacao .row:first-child {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--light-gray);
}

/* Ajuste específico para mobile */
@media (max-width: 768px) {
    .line-variacao {
        padding: 15px;
        margin-bottom: 15px;
    }
    
    .line-variacao .row:first-child {
        margin-bottom: 10px;
        padding-bottom: 8px;
    }
}

.opcoes {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 15px;
    width: 100%;
}

.opcao {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    border: 2px solid var(--medium-gray);
    border-radius: var(--border-radius-sm);
    cursor: pointer;
    transition: var(--transition);
    background: var(--white);
    flex: 1;
    min-width: 200px;
    max-width: calc(50% - 5px);
    box-sizing: border-box;
}

@media (max-width: 768px) {
    .opcoes {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        justify-content: space-between;
        margin-top: 10px;
    }
    
    .opcao {
        /* 2 itens por linha no mobile */
        flex: 0 1 calc(50% - 4px);
        min-width: calc(50% - 4px);
        max-width: calc(50% - 4px);
        margin-bottom: 8px;
        padding: 10px 12px;
        font-size: 14px;
        text-align: center;
        justify-content: center;
        box-sizing: border-box;
    }
}

/* Para telas muito pequenas (menos de 480px) */
@media (max-width: 480px) {
    .opcao {
        padding: 8px 10px;
        font-size: 13px;
    }
}

.opcao:hover {
    border-color: var(--primary-color);
    transform: translateY(-1px);
    box-shadow: var(--shadow-sm);
}

.opcao.active {
    border-color: var(--primary-color);
    background: rgba(var(--primary-color), 0.05);
    box-shadow: 0 0 0 1px var(--primary-color);
}

.opcao .check {
    width: 24px;
    height: 24px;
    border: 2px solid var(--medium-gray);
    border-radius: 50%;
    margin-right: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
    flex-shrink: 0;
}

.opcao.active .check {
    background: var(--primary-color);
    border-color: var(--primary-color);
    color: var(--white);
}

.opcao .check i {
    font-size: 14px;
}

.opcao .detalhes {
    flex: 1;
    min-width: 0; /* Permite que o texto seja truncado se necessário */
}

.opcao .titulo {
    font-weight: 600;
    color: var(--dark-gray);
    display: block;
    margin-bottom: 5px;
    font-size: 14px;
    line-height: 1.3;
}

.opcao .descricao {
    font-size: 12px;
    color: #6c757d;
    line-height: 1.3;
}

/* Ajustes específicos para mobile - 2 colunas */
@media (max-width: 768px) {
    .opcao .check {
        width: 20px;
        height: 20px;
        margin-right: 10px;
    }
    
    .opcao .check i {
        font-size: 12px;
    }
    
    .opcao .titulo {
        font-size: 13px;
        margin-bottom: 3px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .opcao .descricao {
        font-size: 11px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
}

/* Para telas muito pequenas */
@media (max-width: 480px) {
    .opcao .titulo {
        font-size: 12px;
    }
    
    .opcao .descricao {
        font-size: 10px;
    }
}
    line-height: 1.3;
}

/* Escolhas de variação */
.escolhas {
    font-size: 12px;
    color: var(--dark-gray);
    font-weight: 500;
}

/* Layout específico para variações */
.line-variacao .col-md-6 {
    padding: 0 10px !important;
}

.line-variacao .col-md-12 {
    padding: 0 10px !important;
}

/* Validação de variações */
.error-holder {
    margin-top: 10px;
    padding: 8px;
    background: #ffe6e6;
    border-left: 4px solid var(--danger-color);
    border-radius: 4px;
    font-size: 12px;
    color: var(--danger-color);
}

/* Botão de compra - versão compacta e responsiva */
.single-produto .subtotal-adicionar {
    background: var(--white) !important;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1) !important;
    border-top: 1px solid var(--light-gray) !important;
    padding: 12px 15px !important;
    margin: 0 !important;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    width: 100% !important;
}

/* Layout em linha única - flexbox otimizado */
.single-produto .subtotal-adicionar .row {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    flex-wrap: nowrap !important;
}

.single-produto .subtotal-adicionar .col-md-6 {
    padding: 0 !important;
    margin: 0 !important;
    border: none !important;
    display: flex !important;
    align-items: center !important;
}

.single-produto .subtotal-adicionar .col-md-6:first-child {
    flex: 1 !important;
    justify-content: flex-start !important;
}

.single-produto .subtotal-adicionar .col-md-6:last-child {
    flex: 0 0 auto !important;
    justify-content: flex-end !important;
    margin-left: 10px !important;
}

.single-produto .subtotal-adicionar .subtotal {
    font-size: 15px !important;
    font-weight: 600 !important;
    color: var(--dark-gray) !important;
    margin: 0 !important;
    line-height: 1.2 !important;
    white-space: nowrap !important;
}

.single-produto .subtotal-adicionar .subtotal strong {
    margin-right: 8px !important;
}

.single-produto .subtotal-adicionar .subtotal span {
    color: var(--success-color) !important;
    font-size: 16px !important;
    font-weight: 700 !important;
}

.single-produto .subtotal-adicionar .sacola-adicionar {
    background: var(--primary-color) !important;
    color: var(--white) !important;
    border: none !important;
    padding: 10px 16px !important;
    border-radius: 6px !important;
    font-size: 14px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: all 0.2s ease !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    white-space: nowrap !important;
    text-decoration: none !important;
}

.single-produto .subtotal-adicionar .sacola-adicionar:hover {
    background: var(--secondary-color) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15) !important;
}

.single-produto .subtotal-adicionar .sacola-adicionar i {
    font-size: 14px !important;
    margin: 0 !important;
}

/* Compensar altura do botão fixo no mobile */
.single-produto {
    padding-bottom: 70px !important;
}

/* Desktop - linha normal, não fixa */
@media (min-width: 769px) {
    .single-produto {
        padding-bottom: 0 !important;
    }
    
    .single-produto .subtotal-adicionar {
        position: relative !important;
        margin-top: 20px !important;
        padding: 16px 20px !important;
        border-radius: var(--border-radius-sm) !important;
        border: 1px solid var(--light-gray) !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
        bottom: auto !important;
        left: auto !important;
        right: auto !important;
        width: auto !important;
    }
    
    .single-produto .subtotal-adicionar .subtotal {
        font-size: 16px !important;
    }
    
    .single-produto .subtotal-adicionar .subtotal span {
        font-size: 18px !important;
    }
    
    .single-produto .subtotal-adicionar .sacola-adicionar {
        padding: 12px 20px !important;
        font-size: 15px !important;
    }
}

/* CSS padrão para subtotal e botão (sobrescrito pela versão específica da subtotal-adicionar) */
.subtotal {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark-gray);
}

.subtotal span {
    color: var(--success-color);
    font-size: 18px;
    font-weight: 700;
}

.sacola-adicionar {
    background: var(--gradient-primary);
    color: var(--white);
    padding: 12px 25px;
    border-radius: var(--border-radius-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    cursor: pointer;
    transition: var(--transition);
    border: none;
    box-shadow: var(--shadow-sm);
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.sacola-adicionar:hover {
    background: var(--secondary-color);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

/* Formas de pagamento */
.formas-pagamento {
    background: var(--white);
    padding: 20px;
    border-radius: 0;
    margin: 0;
    box-shadow: none;
    text-align: center;
    border-top: 1px solid var(--medium-gray);
    width: 100%;
}

.formas-pagamento-titulo {
    color: var(--primary-color);
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.bandeiras-pagamento {
    max-width: 300px;
    height: auto;
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
}

/* Produtos relacionados */
.relacionados {
    margin-top: 30px;
    padding: 0;
    width: 100%;
}

.categoria {
    background: var(--white);
    padding: 20px;
    border-radius: 0;
    box-shadow: none;
    border-top: 1px solid var(--light-gray);
    width: 100%;
}

/* Ajustes específicos para mobile */
@media (max-width: 768px) {
    .relacionados {
        margin-top: 20px; /* Espaçamento maior superior */
        padding: 0 !important;
        width: 100% !important;
    }
    
    .categoria {
        padding: 15px !important;
        margin: 0 !important;
        border-radius: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    .produtos .row {
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .produtos .col-md-3,
    .produtos .col-sm-6,
    .produtos .col-xs-6 {
        padding: 5px !important;
        margin: 0 !important;
    }
}

.categoria .title {
    font-size: 24px;
    font-weight: 700;
    color: var(--primary-color);
}

.vertudo {
    background: var(--primary-color);
    color: var(--white);
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: var(--transition);
}

.vertudo:hover {
    background: var(--secondary-color);
    transform: scale(1.1);
    color: var(--white);
    text-decoration: none;
}

/* Cards de produtos relacionados com espaçamento */
.produto {
    background: var(--white);
    border-radius: var(--border-radius-sm);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    margin-bottom: 20px;
    margin-right: 15px;
}

.produto:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-md);
}

/* Espaçamento entre produtos relacionados */
.produtos .row {
    margin-left: -7.5px;
    margin-right: -7.5px;
}

.produtos .col-md-3 {
    padding-left: 7.5px;
    padding-right: 7.5px;
    margin-bottom: 15px;
}

/* Ajuste para mobile */
@media (max-width: 768px) {
    .produtos .col-xs-6 {
        padding-left: 5px;
        padding-right: 5px;
        margin-bottom: 10px;
    }
    
    .produto {
        margin-right: 0;
    }
}

.produto .capa {
    height: 200px;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.produto .nome {
    padding: 15px;
    font-weight: 600;
    color: var(--dark-gray);
    font-size: 14px;
    line-height: 1.4;
    display: block;
    border-bottom: 1px solid var(--light-gray);
}

.produto .valor_anterior {
    padding: 0 15px;
    font-size: 12px;
    color: #999;
}

.produto .apenas {
    padding: 0 15px;
    font-size: 12px;
    color: var(--dark-gray);
}

.produto .valor {
    padding: 5px 15px;
    font-size: 16px;
    font-weight: 700;
    color: var(--success-color);
}

.produto .detalhes {
    background: var(--primary-color);
    color: var(--white);
    padding: 12px 15px;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
}

.produto .detalhes:hover {
    background: var(--secondary-color);
}

.produto .detalhes.sem-estoque {
    background: var(--danger-color);
}

/* Espaçamento para mobile */
.fillrelacionados {
    height: 80px;
}

/* Responsividade */
@media (max-width: 768px) {
    .title-icon {
        margin: 10px;
    }
    
    .title-icon span {
        font-size: 20px;
        padding: 12px 20px;
    }
    
    .bread-box {
        margin: 0 10px 15px 10px;
    }
    
    .nome span {
        font-size: 20px;
    }
    
    .valor {
        font-size: 24px;
    }
    
    .produto-detalhes {
        padding: 15px;
    }
    
    .comprar {
        padding: 15px;
        margin: 10px;
        border-radius: var(--border-radius-sm);
    }
    
    .subtotal-adicionar {
        padding: 12px !important;
    }
    
    .relacionados {
        padding: 0;
    }
    
    .categoria {
        padding: 15px;
    }
}

/* Animações */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.single-produto {
    animation: fadeInUp 0.6s ease-out;
}

.relacionados {
    animation: fadeInUp 0.8s ease-out;
}

/* Melhorias de acessibilidade */
.btn:focus,
.sacola-adicionar:focus,
.opcao:focus {
    outline: 3px solid rgba(var(--primary-color), 0.3);
    outline-offset: 2px;
}

/* Estados de loading */
.loadingicon.rotating {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Null states */
.nulled {
    text-align: center;
    padding: 60px 20px;
    color: var(--dark-gray);
    font-size: 18px;
    background: var(--white);
    border-radius: 0;
    box-shadow: none;
    margin: 0;
    width: 100%;
}

.nulled::before {
    content: "😔";
    display: block;
    font-size: 48px;
    margin-bottom: 20px;
}

/* Garantir layout ponta a ponta - APENAS na área do produto */
.single-produto .container-fluid,
.single-produto .container {
    width: 100% !important;
    max-width: 100% !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* CSS específico para mobile - sem espaçamento lateral - APENAS no produto */
@media (max-width: 768px) {
    .single-produto .container-fluid,
    .single-produto .container,
    .single-produto .nopaddmobile {
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
    }
    
    .single-produto {
        padding: 0 !important;
        margin: 0 !important;
    }
    
    .single-produto .row {
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .single-produto .col-md-6,
    .single-produto .col-sm-12,
    .single-produto .col-xs-12 {
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
    }
    
    /* Remover padding lateral da classe padd-container-mobile */
    .padd-container-mobile {
        padding: 0 !important;
        margin: 0 !important;
    }
    
    /* Garantir que a seção azul ocupe 100% da largura */
    .produto-info-header {
        padding: 20px 15px !important; /* Manter padding interno para legibilidade */
        margin: 0 0 20px 0 !important; /* Espaçamento maior inferior */
        border-radius: 0 !important; /* Remove border-radius para ocupar toda largura */
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    /* Garantir que a seção de compra ocupe 100% da largura */
    .comprar {
        padding: 15px !important;
        margin: 0 0 20px 0 !important; /* Espaçamento maior inferior */
        border-radius: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    /* Garantir que variações ocupem 100% da largura */
    .line-variacao {
        padding: 15px !important;
        margin: 0 0 20px 0 !important; /* Espaçamento maior inferior */
        border-radius: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    /* Garantir que formas de pagamento ocupem 100% da largura */
    .formas-pagamento {
        padding: 20px 15px !important;
        margin: 20px 0 0 0 !important; /* Espaçamento maior superior */
        border-radius: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    
    /* Ajustar espaçamento entre seções no mobile */
    .single-produto .col-md-6 {
        margin-bottom: 20px !important; /* Espaço maior entre seções */
    }
    
    /* Espaçamento específico para a seção de formulário */
    .single-produto .row:last-child .col-md-12 {
        margin-top: 20px !important; /* Espaço maior superior para a seção de formulário */
    }
    
    /* Garantir que todas as rows não tenham espaçamento lateral - APENAS no produto */
    .single-produto .row {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }
}

/* Remover qualquer padding/margin dos elementos principais */
.single-produto .row,
.relacionados .row,
.categoria .row {
    margin: 0 !important;
}

.single-produto .col-md-4,
.single-produto .col-md-8 {
    padding: 0 !important;
}

/* Ajustar padding interno apenas onde necessário */
.single-produto .col-md-4 {
    padding-right: 0 !important;
}

.single-produto .col-md-8 {
    padding-left: 0 !important;
}

/* Ajuste para layout meio a meio */
.single-produto .row {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
}

.single-produto .col-md-6 {
    flex: 1;
    max-width: 50%;
    padding: 0 15px;
}

/* Layout desktop meio a meio */
@media (min-width: 769px) {
    .single-produto .col-md-6:first-child {
        padding-right: 10px;
    }
    
    .single-produto .col-md-6:last-child {
        padding-left: 10px;
    }
}

@media (max-width: 768px) {
    /* Reorganizar ordem dos elementos no mobile */
    .single-produto .row {
        flex-direction: column;
    }
    
    .order-first-mobile {
        order: 2 !important; /* Informações vêm em segundo no mobile */
    }
    
    .order-second-mobile {
        order: 1 !important; /* Galeria vem primeiro no mobile */
    }
    
    .single-produto .col-md-6 {
        max-width: 100% !important;
        padding: 0 !important; /* Remove todo padding lateral */
        margin-bottom: 20px !important; /* Espaço maior entre seções */
    }
    
    .single-produto .col-md-4,
    .single-produto .col-md-8 {
        padding: 0 !important;
    }
    
    /* Ajustar altura da galeria no mobile */
    .galeria {
        height: 400px !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
        position: relative;
        background: #f8f9fa;
    }
    
    .carousel-inner {
        height: 400px !important;
        position: relative !important;
        background: #f8f9fa;
        overflow: hidden !important;
    }
    
    .item.zoomer {
        height: 400px !important;
        overflow: hidden !important;
        position: relative !important;
        background: #f8f9fa;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    /* Corrigir especificamente as imagens no mobile */
    .item.zoomer img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
        object-position: center !important;
        min-width: 100% !important;
        min-height: 100% !important;
        max-width: none !important;
        max-height: none !important;
        display: block !important;
        opacity: 1 !important;
        visibility: visible !important;
        /* Reduzir a escala no mobile para evitar problemas */
        transform: scale(1.2) !important;
        position: relative !important;
        z-index: 1 !important;
    }
    
    .item.zoomer iframe {
        width: 100% !important;
        height: 100% !important;
        min-width: 100% !important;
        min-height: 100% !important;
        display: block !important;
        opacity: 1 !important;
        visibility: visible !important;
        border: none !important;
        /* Reduzir a escala para vídeos no mobile */
        transform: scale(1.1) !important;
        position: relative !important;
        z-index: 1 !important;
    }
    
    /* Garantir que os items do carrossel funcionem no mobile */
    .carousel-inner > .item {
        display: none !important;
        position: relative !important;
    }
    
    .carousel-inner > .item.active {
        display: block !important;
        position: relative !important;
    }
    
    /* Links das imagens no mobile */
    .item.zoomer a {
        display: block !important;
        width: 100% !important;
        height: 100% !important;
        overflow: hidden !important;
        position: relative !important;
    }
    
    /* Setas maiores no mobile */
    .seta {
        width: 45px;
        height: 45px;
        font-size: 16px;
        z-index: 1000 !important;
    }
    
    .seta-esquerda {
        left: 10px;
    }
    
    .seta-direita {
        right: 10px;
    }
    
    /* Indicadores maiores no mobile */
    .carousel-indicators {
        bottom: 10px !important;
        z-index: 1000 !important;
    }
    
    .carousel-indicators li {
        width: 12px;
        height: 12px;
        margin: 0 5px;
        background-color: rgba(255,255,255,0.5) !important;
        border: 1px solid rgba(255,255,255,0.8) !important;
    }
    
    .carousel-indicators .active {
        background-color: var(--primary-color) !important;
        border: 1px solid var(--primary-color) !important;
    }
    
    .item.zoomer img {
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
        object-fit: cover;
        object-position: center;
        display: block;
        flex-shrink: 0;
    }
    
    .item.zoomer iframe {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        border: none;
        display: block;
        object-fit: cover;
    }
    
    /* Garantir que todas as seções principais tenham layout ponta a ponta - APENAS no produto */
    .single-produto .middle {
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
    }
    
    .single-produto .container.nopaddmobile {
        max-width: 100% !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
}

/* ================================================ */
/* FORÇAR CORES DA BARRA SUPERIOR EM TODOS OS DISPOSITIVOS */
/* ================================================ */

/* Garantir que a barra superior sempre tenha as cores corretas */
.header .minitop {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
}

.header .minitop .info-badges-desktop .info-badge {
    background: rgba(255,255,255,0.15) !important;
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .info-badges-desktop .info-badge i {
    color: var(--white) !important;
    opacity: 0.9 !important;
}

.header .minitop .info-badges-desktop .info-badge span {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .funcionamento {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .funcionamento .aberto,
.header .minitop .funcionamento .fechado {
    color: inherit !important;
    background: rgba(255,255,255,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(255,255,255,0.2) !important;
}

/* Mobile - garantir que mesmo no mobile as cores sejam consistentes */
@media (max-width: 768px) {
    .header .minitop {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    }
    
    .header .minitop .info-badges-desktop .info-badge {
        color: var(--white) !important;
        background: rgba(255,255,255,0.15) !important;
        font-weight: 600 !important;
        text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
    }
    
    .header .minitop .funcionamento {
        color: var(--white) !important;
        font-weight: 600 !important;
        text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
    }
}
</style>

<div class="sceneElement">

	<div class="header-interna">

		<div class="locked-bar visible-xs visible-sm">

			<div class="avatar">
				<div class="holder">
					<a href="<?php echo $app['url']; ?>">
						<img src="<?php echo $app['avatar']; ?>"/>
					</a>
				</div>	
			</div>

		</div>

		<div class="holder-interna holder-interna-nopadd visible-xs visible-sm"></div>

	</div>

	<?php if( $has_content ) { ?>

		<div class="middle">

			<div class="container nopaddmobile">

				<div class="row rowtitle hidden-xs hidden-sm">

					<div class="col-md-12">
						<div class="bread-box">
							<div class="bread">
								<a href="<?php echo $app['url']; ?>"><i class="lni lni-home"></i></a>
								<span>/</span>
								<a href="<?php echo $app['url']; ?>/categoria/<?php echo data_info( "categorias", $data_content['rel_categorias_id'], "id" ); ?>">Categorias</a>
								<span>/</span>
								<a href="<?php echo $app['url']; ?>/categoria/<?php echo data_info( "categorias", $data_content['rel_categorias_id'], "id" ); ?>"><?php echo data_info( "categorias", $data_content['rel_categorias_id'], "nome" ); ?></a>
								<span>/</span>
								<a href="<?php echo $app['url']; ?>/produto/<?php echo $produto; ?>"><?php echo $data_content['nome']; ?></a>
							</div>
						</div>
					</div>

					<div class="col-md-12 hidden-xs hidden-sm">
						<div class="clearline"></div>
					</div>

				</div>

				<div class="single-produto nost">

					<div class="row">

						<!-- Seção de Galeria - Primeiro no desktop, segundo no mobile -->
						<div class="col-md-6 col-sm-12 col-xs-12 order-second-mobile">

							<div class="galeria">

								<div class="row">

									<div class="col-md-12">

										<?php
										$query_galeria = "SELECT * FROM midia WHERE rel_id = '$produto' ORDER BY id ASC";
										?>

										<div id="carouselgaleria" class="carousel slide" data-ride="carousel">

											<!-- Indicadores -->
											<?php
											$total_galeria_check = mysqli_num_rows(mysqli_query($db_con, $query_galeria));
											$total_slides = $total_galeria_check;
											if ($data_content['video_link']) {
												$total_slides += 2; // vídeo + imagem principal
											} else {
												$total_slides += 1; // apenas imagem principal
											}
											
											if ($total_slides > 1) {
											?>
											<ol class="carousel-indicators">
												<?php for ($i = 0; $i < $total_slides; $i++) { ?>
												<li data-target="#carouselgaleria" data-slide-to="<?php echo $i; ?>" <?php if ($i == 0) echo 'class="active"'; ?>></li>
												<?php } ?>
											</ol>
											<?php } ?>

											<div class="carousel-inner">

                                                <?php 
                                                    if ( $data_content['video_link'] ) 
                                                    {
                                                ?>

        											<div class="item zoomer active">
        												<a data-fancybox="galeria" href="<?php echo imager( $data_content['destaque'] ); ?>">
        													<iframe width="100%" height="345" src="https://www.youtube.com/embed/<?php echo $data_content['video_link']; ?>" frameborder="0" allowfullscreen>
                                                            </iframe>
        												</a>
        											</div>
        											
        											<div class="item zoomer">
												    	<a data-fancybox="galeria" href="<?php echo imager( $data_content['destaque'] ); ?>">
												    		<img src="<?php echo imager( $data_content['destaque'] ); ?>" alt="<?php echo $data_content['nome']; ?>" title="<?php echo $data_content['nome']; ?>"/>
												    	</a>
												    </div>
        										<?php
                                                    } else {
        										?>
        										
        										    <div class="item zoomer active">
												    	<a data-fancybox="galeria" href="<?php echo imager( $data_content['destaque'] ); ?>">
												    		<img src="<?php echo imager( $data_content['destaque'] ); ?>" alt="<?php echo $data_content['nome']; ?>" title="<?php echo $data_content['nome']; ?>"/>
												    	</a>
												    </div>
        							
        										<?php
        										
                                                    }
        										
        										?>

												<?php
												$actual = 0;
												$sql_galeria = mysqli_query( $db_con, $query_galeria );
												$total_galeria = mysqli_num_rows( $sql_galeria );
												while ( $data_galeria = mysqli_fetch_array( $sql_galeria ) ) {
												?>
									

												<div class="item zoomer">
													<a data-fancybox="galeria" href="<?php echo imager( $data_galeria['url'] ); ?>">
														<img src="<?php echo imager( $data_galeria['url'] ); ?>" alt="<?php echo $data_content['nome']; ?>" title="<?php echo $data_content['nome']; ?>"/>
													</a>
												</div>

												<?php $actual++; } ?>

											</div>

											<?php if( $total_slides > 1 ) { ?>

												<a class="left seta seta-esquerda carousel-control" href="#carouselgaleria" data-slide="prev">
													<span class="glyphicon glyphicon-chevron-left"></span>
												</a>
												<a class="right seta seta-direita carousel-control" href="#carouselgaleria" data-slide="next">
													<span class="glyphicon glyphicon-chevron-right"></span>
												</a>

											<?php } ?>

										</div>

									</div>

								</div>

							</div>

						</div>                        <script>
                            $(document).ready(function() {
                                // Detectar se é mobile
                                var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 768;
                                console.log('Dispositivo mobile:', isMobile);
                                
                                // Aguardar o DOM estar totalmente carregado
                                setTimeout(function() {
                                    console.log('Inicializando carrossel...');
                                    
                                    // Destruir carrossel existente se houver
                                    if ($('#carouselgaleria').data('bs.carousel')) {
                                        $('#carouselgaleria').carousel('destroy');
                                    }
                                    
                                    // Garantir que apenas o primeiro item esteja ativo
                                    $('#carouselgaleria .item').removeClass('active');
                                    $('#carouselgaleria .item:first').addClass('active');
                                    $('#carouselgaleria .carousel-indicators li').removeClass('active');
                                    $('#carouselgaleria .carousel-indicators li:first').addClass('active');
                                    
                                    // Função para carregar todas as imagens antes de inicializar
                                    function preloadImages() {
                                        var images = $('#carouselgaleria .item img');
                                        var loadedCount = 0;
                                        var totalImages = images.length;
                                        
                                        console.log('Total de imagens para carregar:', totalImages);
                                        
                                        if (totalImages === 0) {
                                            initCarousel();
                                            return;
                                        }
                                        
                                        images.each(function(index) {
                                            var img = new Image();
                                            var $originalImg = $(this);
                                            var imgSrc = $originalImg.attr('src');
                                            
                                            img.onload = function() {
                                                loadedCount++;
                                                console.log('Imagem carregada:', loadedCount + '/' + totalImages, imgSrc);
                                                if (loadedCount === totalImages) {
                                                    console.log('Todas as imagens carregadas!');
                                                    initCarousel();
                                                }
                                            };
                                            
                                            img.onerror = function() {
                                                loadedCount++;
                                                console.log('Erro ao carregar imagem:', imgSrc);
                                                if (loadedCount === totalImages) {
                                                    console.log('Carregamento finalizado (com alguns erros)');
                                                    initCarousel();
                                                }
                                            };
                                            
                                            img.src = imgSrc;
                                        });
                                    }
                                    
                                    function initCarousel() {
                                        console.log('Inicializando carrossel com imagens carregadas...');
                                        
                                        // Configurações diferentes para mobile e desktop
                                        var carouselConfig = {
                                            interval: false, // Desabilita auto-rotação
                                            wrap: true,
                                            keyboard: !isMobile // Desabilitar teclado no mobile
                                        };
                                        
                                        // Inicializar o carousel
                                        $('#carouselgaleria').carousel(carouselConfig);
                                        
                                        // Função para ajustar tamanho das imagens
                                        function adjustImageSize() {
                                            $('.item.zoomer img').each(function() {
                                                var $img = $(this);
                                                
                                                if (isMobile) {
                                                    // Configurações específicas para mobile
                                                    $img.css({
                                                        'width': '100%',
                                                        'height': '100%',
                                                        'object-fit': 'cover',
                                                        'object-position': 'center',
                                                        'display': 'block',
                                                        'opacity': '1',
                                                        'visibility': 'visible',
                                                        'position': 'relative',
                                                        'z-index': '1'
                                                    });
                                                } else {
                                                    // Configurações para desktop
                                                    $img.css({
                                                        'width': '100%',
                                                        'height': '100%',
                                                        'object-fit': 'cover',
                                                        'object-position': 'center',
                                                        'display': 'block',
                                                        'opacity': '1'
                                                    });
                                                }
                                            });
                                            
                                            // Ajustar vídeos também
                                            $('.item.zoomer iframe').each(function() {
                                                var $iframe = $(this);
                                                $iframe.css({
                                                    'width': '100%',
                                                    'height': '100%',
                                                    'display': 'block',
                                                    'opacity': '1',
                                                    'visibility': 'visible'
                                                });
                                            });
                                        }
                                        
                                        // Event handlers para navegação do carrossel
                                        $('.carousel-control.left, .seta-esquerda').off('click').on('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            console.log('Navegando para slide anterior...');
                                            $('#carouselgaleria').carousel('prev');
                                            
                                            // Ajustar imagens após navegação no mobile
                                            if (isMobile) {
                                                setTimeout(adjustImageSize, 100);
                                            }
                                            
                                            return false;
                                        });
                                        
                                        $('.carousel-control.right, .seta-direita').off('click').on('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            console.log('Navegando para próximo slide...');
                                            $('#carouselgaleria').carousel('next');
                                            
                                            // Ajustar imagens após navegação no mobile
                                            if (isMobile) {
                                                setTimeout(adjustImageSize, 100);
                                            }
                                            
                                            return false;
                                        });
                                        
                                        // Event handler para indicadores
                                        $('.carousel-indicators li').off('click').on('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            var index = $(this).data('slide-to');
                                            console.log('Navegando para slide:', index);
                                            $('#carouselgaleria').carousel(index);
                                            
                                            // Ajustar imagens após navegação no mobile
                                            if (isMobile) {
                                                setTimeout(adjustImageSize, 150);
                                            }
                                            
                                            return false;
                                        });
                                        
                                        // Event handler para mudanças de slide
                                        $('#carouselgaleria').off('slid.bs.carousel slide.bs.carousel').on('slid.bs.carousel', function (e) {
                                            console.log('Slide alterado para:', e.to);
                                            adjustImageSize();
                                            
                                            // Log adicional para debug no mobile
                                            if (isMobile) {
                                                console.log('Mobile - Verificando imagem ativa:', $('#carouselgaleria .item.active img').attr('src'));
                                            }
                                        });
                                        
                                        $('#carouselgaleria').on('slide.bs.carousel', function (e) {
                                            console.log('Mudando para slide:', e.to);
                                        });
                                        
                                        // Executar ajuste inicial
                                        adjustImageSize();
                                        
                                        // Ajustar imagens no redimensionamento da tela
                                        $(window).resize(function() {
                                            adjustImageSize();
                                        });
                                        
                                        // Suporte a touch/swipe melhorado para mobile
                                        if (isMobile) {
                                            var startX = 0;
                                            var endX = 0;
                                            var startY = 0;
                                            var endY = 0;
                                            
                                            $('#carouselgaleria').off('touchstart touchend').on('touchstart', function(e) {
                                                startX = e.originalEvent.touches[0].clientX;
                                                startY = e.originalEvent.touches[0].clientY;
                                            });
                                            
                                            $('#carouselgaleria').on('touchend', function(e) {
                                                endX = e.originalEvent.changedTouches[0].clientX;
                                                endY = e.originalEvent.changedTouches[0].clientY;
                                                
                                                var diffX = startX - endX;
                                                var diffY = startY - endY;
                                                
                                                // Verificar se é um swipe horizontal (não vertical)
                                                if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                                                    if (diffX > 0) {
                                                        // Swipe left - próximo slide
                                                        console.log('Swipe left detectado');
                                                        $('#carouselgaleria').carousel('next');
                                                    } else {
                                                        // Swipe right - slide anterior
                                                        console.log('Swipe right detectado');
                                                        $('#carouselgaleria').carousel('prev');
                                                    }
                                                }
                                            });
                                        }
                                        
                                        console.log('Carrossel inicializado com sucesso!');
                                    }
                                    
                                    // Iniciar o processo de carregamento das imagens
                                    preloadImages();
                                    
                                }, isMobile ? 800 : 500); // Aguardar mais tempo no mobile
                            });
						</script>

						<!-- Seção de Informações - Segundo no desktop, primeiro no mobile -->
						<div class="col-md-6 col-sm-12 col-xs-12 order-first-mobile">

							<div class="padd-container-mobile">

								<!-- Seção azul com informações do produto -->
								<div class="produto-info-header">
									<div class="nome">
										<span><?php echo htmlclean( $data_content['nome'] ); ?></span>
									</div>
									
									<?php if( $data_content['ref'] ) { ?>
									<div class="ref-info">
										<span class="thelabel">REF:</span>
										<span class="ref-value">#<?php echo htmlclean( $data_content['ref'] ); ?></span>
									</div>
									<?php } ?>
									
									<?php
									// Seta valor
									if ($data_content['oferta'] == "1") {
									    $valor_final = $data_content['valor_promocional'];
									} else {
									    $valor_final = $data_content['valor'];
									}
									?>

									<?php if ($valor_final > '0.00') { ?>
									<div class="preco-info">
										<span class="thelabel">Preço:</span>
										<?php if ($data_content['oferta'] == "1") { ?>
											<div class="valor_anterior">
												De: <strike>R$ <?php echo dinheiro($data_content['valor'], "BR"); ?></strike>
											</div>
										<?php } ?>
										<div class="valor_atual">
											Por apenas <strong>R$ <?php echo dinheiro($valor_final, "BR"); ?></strong>
										</div>
									</div>
																	<?php } ?>
									
									<?php if($data_content['estoque'] == 2) { ?>
									<div class="estoque-info">
										<span class="thelabel">Em Estoque:</span>
										<div class="estoque-quantidade">
											<span id="em-estoque"><?php echo $data_content['posicao'] ?></span> unidades disponíveis
										</div>
									</div>
									<?php } ?>
									
									<?php if( $data_content['descricao'] ) { ?>
									<div class="detalhes-info">
										<span class="thelabel">Detalhes:</span>
										<div class="descricao">
											<span><?php echo nl2br( htmlclean( $data_content['descricao'] ) ); ?></span>
										</div>
									</div>
									<?php } ?>
									
									<div class="link-info">
										<span class="thelabel">Compartilhar:</span>
										<a href="https://api.whatsapp.com/send?text=<?php print $pegaurl; ?>" target="_blank" class="btn btn-success btn-sm">
											<i class="lni lni-whatsapp"></i> Compartilhe no WhatsApp
										</a>
									</div>
								</div>

							</div>

						</div>

					</div>

					<!-- Seção de Formulário de Compra - Terceiro, sempre embaixo no mobile -->
					<div class="row">
						
						<div class="col-md-12">

							<div class="padd-container-mobile">

								<form id="the_form" method="POST">
								    
								    <?php if( verifica_horario($app['id']) == "disabled" ) { ?>
								    
								        <?php if ( data_info( "estabelecimentos", $app['id'], "funcionamento") == "1" ) { ?>
								                
            								<div class="comprar">
            
            										<?php if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) { ?>
            
            											<?php
            											$x = 0;
            											$variacao = json_decode( $data_content['variacao'], TRUE );
            											for ( $x=0; $x < count( $variacao ); $x++ ){
            											?>
            
            											<div class="line line-variacao" min="<?php echo htmljson( $variacao[$x]['escolha_minima'] ); ?>" max="<?php echo htmljson( $variacao[$x]['escolha_maxima'] ); ?>">
            												<div class="row">
            													<div class="col-md-6">
            														<span class="thelabel pull-left">
            															<?php echo htmljson( $variacao[$x]['nome'] ) ;?>
            														</span>
            													</div>
            													<div class="col-md-6">
            														<span class="escolhas pull-right">
            															Minímo: <?php echo htmljson( $variacao[$x]['escolha_minima'] ) ;?> E Máximo: <?php echo htmljson( $variacao[$x]['escolha_maxima'] ) ;?>
            														</span>
            													</div>
            												</div>
            												<div class="row">	
            													<div class="col-md-12">
            
            														<div class="opcoes">
            
            															<?php
            															for( $y=0; $y < count( $variacao[$x]['item'] ); $y++ ){
            															?>
            
            															<div class="opcao <?php if( variacao_opcao_ativa( $data_content['id'],$x,$y ) ) { echo 'active'; }; ?>" variacao-item="<?php echo $y; ?>" nomeda-variacao="<?php echo htmljson( $variacao[$x]['nome'] ) ;?>" valor-adicional="<?php echo htmljson( $variacao[$x]['item'][$y]['valor'] ); ?>">
            
            																<div class="check">
            																	<i class="lni"></i>
            																</div>
            																<div class="detalhes">
            																	<span class="titulo">
            																		<?php echo htmljson( $variacao[$x]['item'][$y]['nome'] ); ?>
            																		<?php if( $variacao[$x]['item'][$y]['valor'] ) { ?>
            																		(+ R$ <?php echo dinheiro( htmljson( $variacao[$x]['item'][$y]['valor'] ), "BR" ); ?>)
            																		<?php } ?>
            																	</span>
            																	<span class="descricao"><?php echo htmljson( $variacao[$x]['item'][$y]['descricao'] ); ?></span>
            																</div>
            																<div class="clear"></div>
            
            															</div>
            															
            
            															<?php } ?>
            
            														</div>
            														<div class="clear"></div>
            														<input class="fakehidden variacao_validacao" type="text" name="variacao_<?php echo $x; ?>_validacao" value=""/>
            														<input class="fakehidden variacao_escolha" type="text" name="variacao[<?php echo $x; ?>]" value=""/>
            														<div class="error-holder"></div>
            													</div>
            												</div>
            											</div>
            
            											<?php } ?>
            
            										<?php } ?>
            
            										<div class="line quantidade">
            											<div class="row">
            												<div class="col-md-3 col-sm-2 col-xs-2">
            													<span class="thelabel hidden-xs hidden-sm">Quantidade:</span>
            													<span class="thelabel visible-xs visible-sm">Qntd:</span>
            												</div>
            												<div class="col-md-9 col-sm-10 col-xs-10">
            													<div class="campo-numero pull-right">
            														<i class="decrementar lni lni-minus" onclick="decrementar('#quantidade');"></i>
            														<input id="quantidade" type="number" name="quantidade" value="<?php if( $_SESSION['sacola'][$app['id']][$data_content['id']]['quantidade'] ){ echo htmlclean( $_SESSION['sacola'][$app['id']][$data_content['id']]['quantidade'] ); } else { echo '1'; } ?>"/>
            														<i class="incrementar lni lni-plus" onclick="incrementar('#quantidade');"></i>
            													</div>
            												</div>
            											</div>
            										</div>
            										<div class="line observacoes">
            											<div class="row">
            												<div class="col-md-3 col-sm-2 col-xs-2">
            													<span class="thelabel hidden-xs hidden-sm">Observações:</span>
            													<span class="thelabel visible-xs visible-sm">Obs:</span>
            												</div>
            												<div class="col-md-9 col-sm-10 col-xs-10">
            													<textarea id="observacoes" rows="5" name="observacoes" placeholder="Observações:"><?php echo htmlclean( $_SESSION['sacola'][$app['id']][$data_content['id']]['observacoes'] ); ?></textarea>
            												</div>
            											</div>
            										</div>


													<div class="line botoes subtotal-adicionar">
														<div class="row">
															<div class="col-md-6">
																<div class="subtotal">
																	<strong>Valor:</strong>
																	<span>R$ <?php echo dinheiro($data_content['valor_promocional'], "BR"); ?></span>
																</div>
															</div>
															<div class="col-md-6">
																<span class="sacola-adicionar botao-acao">
																	<i class="icone icone-sacola"></i> Comprar
																</span>
															</div>
														</div>
													</div>
                                                
								                
								        <?php } else { ?>
								        
								            <div class="comprar">
        
        										<div class="line quantidade">
        											<div class="row">
        												<div class="col-md-3 col-sm-2 col-xs-2 hidden-xs hidden-sm">
        													<span class="thelabel">Aviso:</span>
        												</div>
        												<div class="col-md-9 col-sm-12 col-xs-12">
        													<span>O estabelecimento encontra-se temporariamente fechado, impossibilitando a realização de pedidos no momento!</span>
        												</div>
        											</div>
        										</div>
        										<div class="line botoes">
        											<div class="row">
        												<div class="col-md-12">
        													<a target="_blank" href="https://wa.me/55<?php echo clean_str( htmlclean( $app['contato_whatsapp'] ) ); ?>" class="botao-acao pull-right"><i class="lni lni-whatsapp"></i> <span>Entre em contato</span></a>
        												</div>
        											</div>
        										</div>
        
        									</div>
        									
								        <?php } ?>
								    
								    <?php } else { ?>
								    
								        <?php if( verifica_horario($app['id']) == "open" ) { ?>
								    
        								    <div class="comprar">
        
        										<?php if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) { ?>
        
        											<?php
        											$x = 0;
        											$variacao = json_decode( $data_content['variacao'], TRUE );
        											for ( $x=0; $x < count( $variacao ); $x++ ){
        											?>
        
        											<div class="line line-variacao" min="<?php echo htmljson( $variacao[$x]['escolha_minima'] ); ?>" max="<?php echo htmljson( $variacao[$x]['escolha_maxima'] ); ?>">
        												<div class="row">
        													<div class="col-md-6">
        														<span class="thelabel pull-left">
        															<?php echo htmljson( $variacao[$x]['nome'] ) ;?>
        														</span>
        													</div>
        													<div class="col-md-6">
        														<span class="escolhas pull-right">
        															Minímo: <?php echo htmljson( $variacao[$x]['escolha_minima'] ) ;?> e Máximo: <?php echo htmljson( $variacao[$x]['escolha_maxima'] ) ;?>
        														</span>
        													</div>
        												</div>
        												<div class="row">	
        													<div class="col-md-12">
        
        														<div class="opcoes">
        
        															<?php
        															for( $y=0; $y < count( $variacao[$x]['item'] ); $y++ ){
        															?>
        
        															<div class="opcao <?php if( variacao_opcao_ativa( $data_content['id'],$x,$y ) ) { echo 'active'; }; ?>" variacao-item="<?php echo $y; ?>" nomeda-variacao="<?php echo htmljson( $variacao[$x]['nome'] ) ;?>" valor-adicional="<?php echo htmljson( $variacao[$x]['item'][$y]['valor'] ); ?>">
        
        																<div class="check">
        																	<i class="lni"></i>
        																</div>
        																<div class="detalhes">
        																	<span class="titulo">
        																		<?php echo htmljson( $variacao[$x]['item'][$y]['nome'] ); ?>
        																		<?php if( $variacao[$x]['item'][$y]['valor'] ) { ?>
        																		(+ R$ <?php echo dinheiro( htmljson( $variacao[$x]['item'][$y]['valor'] ), "BR" ); ?>)
        																		<?php } ?>
        																	</span>
        																	<span class="descricao"><?php echo htmljson( $variacao[$x]['item'][$y]['descricao'] ); ?></span>
        																</div>
        																<div class="clear"></div>
        
        															</div>
        															
        
        															<?php } ?>
        
        														</div>
        														<div class="clear"></div>
        														<input class="fakehidden variacao_validacao" type="text" name="variacao_<?php echo $x; ?>_validacao" value=""/>
        														<input class="fakehidden variacao_escolha" type="text" name="variacao[<?php echo $x; ?>]" value=""/>
        														<div class="error-holder"></div>
        													</div>
        												</div>
        											</div>
        
        											<?php } ?>
        
        										<?php } ?>
        
        										<div class="line quantidade">
        											<div class="row">
        												<div class="col-md-3 col-sm-2 col-xs-2">
        													<span class="thelabel hidden-xs hidden-sm">Quantidade:</span>
        													<span class="thelabel visible-xs visible-sm">Qntd:</span>
        												</div>
        												<div class="col-md-9 col-sm-10 col-xs-10">
        													<div class="campo-numero pull-right">
        														<i class="decrementar lni lni-minus" onclick="decrementar('#quantidade');"></i>
        														<input id="quantidade" type="number" name="quantidade" value="<?php if( $_SESSION['sacola'][$app['id']][$data_content['id']]['quantidade'] ){ echo htmlclean( $_SESSION['sacola'][$app['id']][$data_content['id']]['quantidade'] ); } else { echo '1'; } ?>"/>
        														<i class="incrementar lni lni-plus" onclick="incrementar('#quantidade');"></i>
        													</div>
        												</div>
        											</div>
        										</div>
        										<div class="line observacoes">
        											<div class="row">
        												<div class="col-md-3 col-sm-2 col-xs-2">
        													<span class="thelabel hidden-xs hidden-sm">Observações:</span>
        													<span class="thelabel visible-xs visible-sm">Obs:</span>
        												</div>
        												<div class="col-md-9 col-sm-10 col-xs-10">
        													<textarea id="observacoes" rows="5" name="observacoes" placeholder="Observações:"><?php echo htmlclean( $_SESSION['sacola'][$app['id']][$data_content['id']]['observacoes'] ); ?></textarea>
        												</div>											</div>
										</div>


												<div class="line botoes subtotal-adicionar">
													<div class="row">
														<div class="col-md-6">
															<div class="subtotal">
																<strong>Total:</strong>
																<span>R$ <?php echo dinheiro($data_content['valor_promocional'], "BR"); ?></span>
															</div>
														</div>
														<div class="col-md-6" style="text-align: right;">
															<span class="sacola-adicionar botao-acao">
																<i class="icone icone-sacola"></i> Comprar
															</span>
														</div>
													</div>
												</div>


								    
								        <?php } else if ( verifica_horario($app['id']) == "close" ) { ?>
        								            <div class="comprar">
        
        										<div class="line quantidade">
        											<div class="row">
        												<div class="col-md-3 col-sm-2 col-xs-2 hidden-xs hidden-sm">
        													<span class="thelabel">Aviso:</span>
        												</div>
        												<div class="col-md-9 col-sm-12 col-xs-12">
        													<span>O estabelecimento encontra-se temporariamente fechado, impossibilitando a realização de pedidos no momento!</span>
        												</div>
        											</div>
        										</div>
        										<div class="line botoes">
        											<div class="row">
        												<div class="col-md-12">
        													<a target="_blank" href="https://wa.me/55<?php echo clean_str( htmlclean( $app['contato_whatsapp'] ) ); ?>" class="botao-acao pull-right"><i class="lni lni-whatsapp"></i> <span>Entre em contato</span></a>
        												</div>
        											</div>
        										</div>
        
        									</div>
								        <?php } ?>
								    
								    <?php } ?>

								</form>

								

								<div class="line formas-pagamento">
								    <div class="row">
								        <div class="col-md-12 text-center">
								            <h3 class="formas-pagamento-titulo">
								                <i class="lni lni-credit-cards"></i> Formas de Pagamento
								            </h3>
								        </div>
								        <div class="col-md-12 text-center">
								            <img 
								                src="<?php echo $app['url']; ?>/_core/_cdn/img/bandeiras.png" 
								                alt="Bandeiras de pagamento" 
								                class="img-fluid bandeiras-pagamento">
								        </div>
								    </div>
								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

		<?php
		$cat_id = $data_content['rel_categorias_id'];
		$eid = $app['id'];
		$query_relacionados = mysqli_query( $db_con, "SELECT * FROM produtos WHERE rel_estabelecimentos_id = '$eid' AND rel_categorias_id = '$cat_id' AND id != '$produto' AND visible = '1' AND status = '1' ORDER BY id DESC LIMIT 4" );
		$total_relacionados = mysqli_num_rows( $query_relacionados );
		?>

		<?php if( $total_relacionados >= 1 ) { ?>

		<div class="container relacionados">

			<div class="categoria">

				<div class="row">

					<div class="col-md-10 col-sm-10 col-xs-10">
						
						<span class="title">Veja também</span>
					
					</div>

					<div class="col-md-2 col-sm-2 col-xs-2">
						
						<a class="vertudo" href="<?php echo $app['url']; ?>/categoria/<?php echo $cat_id; ?>"><i class="lni lni-arrow-right"></i></a>
					
					</div>

				</div>

				<div class="produtos">
    <div class="row tv-grid">
        <?php
        // Se não houver produtos nesta página, exibir mensagem
        if ($total_relacionados == 0) {
            echo '<div class="col-md-12 text-center"><p style="padding: 20px;">Nenhum produto encontrado nesta categoria.</p></div>';
        }

        $count_produtos = 0; // Contador para validar número de produtos exibidos

        while ($data_produtos = mysqli_fetch_array($query_relacionados)) {
            // Verificação completa para produtos com dados incompletos
            if (!$data_produtos['nome'] || !$data_produtos['id'] || !$data_produtos['destaque']) {
                error_log("Produto incompleto: ID={$data_produtos['id']}, Nome={$data_produtos['nome']}, Destaque={$data_produtos['destaque']}");
                continue; // Pula produtos com dados incompletos
            }

            $count_produtos++; // Incrementa contador de produtos válidos

            // Define o valor final (oferta ou preço normal)
            $valor_final = ($data_produtos['oferta'] == "1") ? $data_produtos['valor_promocional'] : $data_produtos['valor'];

            // Garante que o valor_final é um número válido
            $valor_final = is_numeric($valor_final) ? $valor_final : 0;
        ?>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <div class="produto">
                <a href="<?php echo $app['url']; ?>/produto/<?php echo $data_produtos['id']; ?>" title="<?php echo $data_produtos['nome']; ?>">
                    <!-- Imagem do produto com fallback para imagens não disponíveis -->
                    <div class="capa" style="background-image: url(<?php echo thumber($data_produtos['destaque'] ? $data_produtos['destaque'] : 'assets/img/no-image.jpg', 450); ?>);"></div>
                    <span class="nome"><?php echo htmlclean($data_produtos['nome']); ?></span>
                    
                    <?php if ($valor_final > 0) { ?>
                        <?php if ($data_produtos['oferta'] == "1" && $data_produtos['valor'] > 0) { ?>
                            <!-- Exibição de preço promocional com valor original riscado -->
                            <span class="valor_anterior">De: <?php echo dinheiro($data_produtos['valor'], "BR"); ?></span>
                        <?php } else { ?>
                            <span class="valor_anterior invisible">&nbsp;</span>
                        <?php } ?>
                        <span class="apenas">Por apenas</span>
                        <span class="valor">R$ <?php echo dinheiro($valor_final, "BR"); ?></span>
                        
                        <!-- Verificação de disponibilidade em estoque -->
                        <?php if ($data_produtos['estoque'] == 1 || ($data_produtos['estoque'] == 2 && $data_produtos['posicao'] > 0)) { ?>
                            <div class="detalhes"><i class="icone icone-sacola"></i> <span>Comprar</span></div>
                        <?php } else { ?>
                            <div class="detalhes sem-estoque"><i class="lni lni-close"></i> <span>Sem Estoque</span></div>
                        <?php } ?>
                    <?php } else { ?>
                        <!-- Produto com preço variável/opcionais -->
                        <span class="apenas">Este item possui</span>
                        <span class="apenas">opcionais</span>
                        <span class="valor" style="color:#FFFFFF">.</span>
                        <div class="detalhes"><i class="icone icone-sacola"></i> <span>Selecione</span></div>
                    <?php } ?>
                </a>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

			</div>

		</div>

		<?php } else { ?>

		<div class="fillrelacionados visible-xs visible-sm"></div>

		<?php } ?>

	<?php } else { ?>

		<div class="middle">

			<div class="container">

				<div class="row">

					<span class="nulled nulled-content">Produto inválido ou inativo!</span>

				</div>

			</div>

		</div>

	<?php } ?>

</div>

<?php 
// FOOTER
$system_footer .= "";
include($virtualpath.'/_layout/rdp.php');
include($virtualpath.'/_layout/footer.php');
?>


<script>

$(document).on('change','#the_form',function(e){

	<?php
	if( $data_content['oferta'] == "1" ) {
		$valor_final = $data_content['valor_promocional'];
	} else {
		$valor_final = $data_content['valor'];
	}
	?>

var total = parseFloat( "<?php echo $valor_final; ?>" );

var vezes = parseFloat( $("#quantidade").val() );
total = total * vezes;
total = parseFloat( total ).toFixed(2);

$('.subtotal').html('<strong>Total:</strong> R$ ' + total );

});

$("#the_form").trigger("change");

<?php if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) { ?>

	$(document).ready( function() {
	          
	  var form = $("#the_form");
	  form.validate({
	      focusInvalid: true,
	      invalidHandler: function() {
	      },
	      errorPlacement: function errorPlacement(error, element) { 
	      	element.closest(".line-variacao").find(".error-holder").html(error); 
	      },
	      rules: {
			<?php
			if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) {
				$variacao = json_decode( $data_content['variacao'], TRUE );
				if (is_array($variacao) && count($variacao) > 0) {
					$rules = array();
					for ( $x=0; $x < count( $variacao ); $x++ ){
						$rule = "variacao_".$x."_validacao: {";
						if( htmljson( $variacao[$x]['escolha_minima'] ) >= 1 ) {
							$rule .= "required: true,";
						}
						$rule .= "min: ".htmljson( $variacao[$x]['escolha_minima'] ).",";
						$rule .= "max: ".htmljson( $variacao[$x]['escolha_maxima'] );
						$rule .= "}";
						$rules[] = $rule;
					}
					echo implode(",\n\t\t\t", $rules);
				} else {
					echo "dummy: true"; // regra vazia para evitar erro de sintaxe
				}
			} else {
				echo "dummy: true"; // regra vazia para evitar erro de sintaxe
			}
			?>
	      },
	      messages: {
			<?php
			if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) {
				$variacao = json_decode( $data_content['variacao'], TRUE );
				if (is_array($variacao) && count($variacao) > 0) {
					$messages = array();
					for ( $x=0; $x < count( $variacao ); $x++ ){
						$message = "variacao_".$x."_validacao: {";
						if( htmljson( $variacao[$x]['escolha_minima'] ) >= 1 ) {
							$message .= "required: 'Campo obrigatório',";
						}
						$message .= "min: 'Você deve escolher ao menos ".htmljson( $variacao[$x]['escolha_minima'] )."',";
						$message .= "max: 'Você deve escolher no máximo ".htmljson( $variacao[$x]['escolha_maxima'] )."'";
						$message .= "}";
						$messages[] = $message;
					}
					echo implode(",\n\t\t\t", $messages);
				} else {
					echo "dummy: 'dummy message'"; // mensagem vazia para evitar erro de sintaxe
				}
			} else {
				echo "dummy: 'dummy message'"; // mensagem vazia para evitar erro de sintaxe
			}
			?>
	      }
	  });

	});

	function ativachecks() {

		$(".line-variacao").each(function() {
			var contachecks = 0;
			var selecteds = "";
			$(this).find(".opcao.active").each(function() {
				contachecks++;
				selecteds = selecteds + $(this).attr("variacao-item") + ",";
			});	
			selecteds = selecteds.substring(0,selecteds.length - 1);
			$(this).find(".variacao_validacao").attr("value",contachecks);
			$(this).find(".variacao_escolha").attr("value",selecteds);
		});
		$("#the_form").trigger("change");
		$(".variacao_validacao").valid();

	}

	$( ".opcoes .opcao" ).click(function() {

		var min = parseInt( $(this).closest(".line-variacao").attr("min") );
		var max = parseInt( $(this).closest(".line-variacao").attr("max") );
		var parcial = parseInt( $(this).closest(".line-variacao").find(".variacao_validacao").val() );

		if( $(this).hasClass("active") ) {
			$( this ).removeClass("active");
		} else {
			if( parcial < max ) {
				$( this ).addClass("active");
			} else {
				alert("Você já escolheu o maximo de opções permitidas, você deve remover alguma caso queira escolher uma nova!");
			}
		}
		ativachecks();
		$( "#the_form" ).trigger("change");

	});
	
	
	
		$(document).on('change','#the_form',function(e){

		var total = parseFloat( "<?php echo $data_content['valor_promocional']; ?>" );

		$( ".opcao.active" ).each(function() {
		
			var adiciona = parseFloat( $( this ).attr("valor-adicional") );
			var nomedavariacao = ( $( this ).attr("nomeda-variacao") );
			
			// Funçao para calcular o maior valor da pizza 
			
			if( nomedavariacao == "Escolha o sabor da pizza abaixo" && adiciona > total && adiciona > 0  ) {
			
				total = adiciona;
				
			}
			
			if( nomedavariacao !== "Escolha o sabor da pizza abaixo" && adiciona > 0  ) {
			
				total = total + adiciona;
				
			}
			
			
			
			
		});

        var vezes = parseFloat( $("#quantidade").val() );
		total = total * vezes;
		total = parseFloat( total ).toFixed(2);

		$('.subtotal').html('<strong>Total:</strong> R$ ' + total );

	});
	
	
	
	

	$( document ).ready(function() {

		$( ".opcoes .opcao .check" ).each(function() {
			var alturacheck = $( this ).parent().height();
			$( this ).css("height",alturacheck);
		});

		ativachecks();

	});

<?php } ?>

$( ".sacola-adicionar" ).click(function() {

	// Verificar se há link de afiliado ativo
	<?php if( $link_afiliado_data['ativo'] == 1 && !empty($link_afiliado_data['link_vendas']) ) { ?>
		// Redirecionar para o link de afiliado
		window.open('<?php echo htmlspecialchars($link_afiliado_data['link_vendas']); ?>', '_blank');
		return false;
	<?php } else { ?>
		// Funcionamento normal do sistema
		if( $('label.error:visible').length ){

			alert("Existem campos obrigatórios a serem preenchidos!");

			$('html, body').animate({
		        scrollTop: $("label.error:visible").offset().top-150
		    }, 500);

		}

		<?php if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) { ?>
		if( $(".variacao_validacao").valid() ) {
		<?php } ?>

			var eid = "<?php echo $app['id']; ?>";
			var former = "#the_form";
			var token = "<?php echo session_id(); ?>";
			var produto = "<?php echo $produto; ?>";
			var modo = "adicionar";
			var data = $("#the_form").serialize();

		$("#modalcarrinho .modal-body").html('<div class="adicionado"><i class="loadingicon lni lni-reload rotating"></i><div>');
		$.post( "<?php echo $app['url']; ?>/app/estabelecimento/_ajax/sacola.php", { token: token, produto: produto, modo: modo, data: data })
		.done(function( data ) {
			$( "#modalcarrinho .modal-body" ).html( data );
		});
		$("#modalcarrinho").modal("show");
		sacola_count(eid,token);

	<?php if( has_variacao($data_content['id']) && $app['funcionalidade_variacao'] == "1" ) { ?>
	}
	<?php } ?>
	
	var quantidade_valor = $("#quantidade").val()
	if (parseInt(document.querySelector('#em-estoque').innerHTML) >= $("#quantidade").val()) {
    	$.ajax({
          url: window.location.href,
          type: "POST",
          data: {
            quantidade_para_remover: quantidade_valor
          },
          success: function(response) {
            document.querySelector('#em-estoque').innerHTML = (document.querySelector('#em-estoque').innerHTML - quantidade_valor)
          }
        });
	}
	
	<?php } // Fim da condição do link de afiliado ?>

});

</script>

<div class="releaseclick"></div>