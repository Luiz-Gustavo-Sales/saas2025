<?php
// ************************************************
// CONFIGURAÇÕES INICIAIS E CARREGAMENTO DE RECURSOS
// ************************************************

// Carregando definições do sistema
include($virtualpath.'/_layout/define.php');

// Configurações globais da aplicação
global $app;
is_active($app['id']);
global $inparametro;
$back_button = "true";

// ************************************************
// CONSULTAS AO BANCO DE DADOS E PARÂMETROS
// ************************************************

// Identificadores e parâmetros de filtro
$app_id = $app['id'];
$busca = mysqli_real_escape_string($db_con, $_GET['busca']);
$categoria = $inparametro;
$filtro = mysqli_real_escape_string($db_con, $_GET['filtro']);

// Captura URL atual para compartilhamento
$pegaurlx = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// Verificação de existência da categoria
$query_content = mysqli_query($db_con, "SELECT * FROM categorias WHERE rel_estabelecimentos_id = '$app_id' AND id = '$categoria' AND status = '1' ORDER BY ordem ASC");
$has_content = mysqli_num_rows($query_content);
if(!$categoria) {
    $has_content = "true"; // Categoria "todas" é sempre válida
}

// Função para ajustar brilho das cores
function adjust_brightness($hex, $percent) {
    if (!$hex) return '#2c3e50';
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + ($r * $percent / 100)));
    $g = max(0, min(255, $g + ($g * $percent / 100)));
    $b = max(0, min(255, $b + ($b * $percent / 100)));
    
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}

// Construção dos parâmetros para URLs
$getdata = "?";
if($busca) {
    $getdata .= "busca=".$busca."&";
}
$getdata_unfilter = substr($getdata, 0, -1);
if($getdata_unfilter == "") {
    $getdata_unfilter = "?";
}
if($filtro) {
    $getdata .= "filtro=".$filtro."&";
}
$getdata = substr($getdata, 0, -1);

// ************************************************
// CONFIGURAÇÕES DE SEO (OTIMIZAÇÃO PARA BUScADORES)
// ************************************************

// Definição do nome da categoria para SEO
$categoria_nome = data_info("categorias", $categoria, "nome");
if(!$categoria_nome && $categoria) {
    $categoria_nome = "Categoria inválida";
} else {
    if(!$categoria_nome) {
        $categoria_nome = "Todas as categorias";
    }
}

// Personalização do título para filtros especiais
if($filtro == "4") {
    $categoria_nome .= " em oferta";
}
if($busca) {
    $categoria_nome = "Buscar";
}

// Configurações gerais de SEO
$seo_subtitle = $app['title']." - ".$categoria_nome;
$seo_description = $categoria_nome." ".$app['title']." no ".$seo_title;
$seo_keywords = $app['title'].", ".$seo_title;
$seo_image = thumber($app['avatar_clean'], 400);

// ************************************************
// INCLUSÃO DOS ARQUIVOS DE LAYOUT
// ************************************************

$system_header .= "";
include($virtualpath.'/_layout/head.php');
include($virtualpath.'/_layout/top.php');
include($virtualpath.'/_layout/sidebars.php');
include($virtualpath.'/_layout/modal.php');
instantrender();
?>

<style>
/* ================================================ */
/* DESIGN MODERNO PARA PÁGINA DE CATEGORIAS */
/* ================================================ */

/* Variáveis CSS dinâmicas baseadas na cor do estabelecimento */
:root {
    --primary-color: <?php echo $app['cor'] ?: '#2c3e50'; ?>;
    --secondary-color: <?php echo adjust_brightness($app['cor'] ?: '#2c3e50', -30); ?>;
    --accent-color: <?php echo adjust_brightness($app['cor'] ?: '#2c3e50', 20); ?>;
    --success-color: #27ae60;
    --danger-color: #e74c3c;
    --warning-color: #f39c12;
    --light-gray: #f8f9fa;
    --medium-gray: #e9ecef;
    --dark-gray: #495057;
    --white: #ffffff;
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.12);
    --shadow-lg: 0 8px 24px rgba(0,0,0,0.15);
    --border-radius: 16px;
    --border-radius-sm: 8px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    --gradient-primary: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    --gradient-bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* ================================================ */
/* CORREÇÃO DAS CORES DA BARRA SUPERIOR (MINITOP) */
/* ================================================ */

/* Barra superior com cor dinâmica do estabelecimento */
.minitop {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    padding: 12px 0 !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important;
}

/* Info badges da barra superior com texto branco */
.info-badges-desktop .info-badge {
    background: rgba(255,255,255,0.15) !important;
    color: var(--white) !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    padding: 6px 12px !important;
    margin-right: 12px !important;
    transition: var(--transition) !important;
    backdrop-filter: blur(10px) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
}

.info-badges-desktop .info-badge:hover {
    background: rgba(255,255,255,0.25) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2) !important;
}

.info-badges-desktop .info-badge i {
    color: var(--white) !important;
    margin-right: 6px !important;
    font-weight: bold !important;
    opacity: 0.9 !important;
}

.info-badges-desktop .info-badge span {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

/* Status de funcionamento */
.funcionamento {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.funcionamento .aberto {
    color: #4CAF50 !important;
    background: rgba(76,175,80,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(76,175,80,0.3) !important;
}

.funcionamento .fechado {
    color: #f44336 !important;
    background: rgba(244,67,54,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(244,67,54,0.3) !important;
}

.funcionamento i {
    margin-right: 6px !important;
    font-weight: bold !important;
}

/* ================================================ */
/* CONFIGURAÇÕES BASE E LAYOUT RESPONSIVO */
/* ================================================ */

/* Reset e configurações base */
* {
    box-sizing: border-box;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: var(--dark-gray);
    background: var(--light-gray);
    margin: 0;
    padding: 0;
}

/* Layout principal */
.sceneElement {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    padding: 0;
    margin: 0;
    width: 100%;
    overflow-x: hidden;
}

/* Container responsivo */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
}

.container.nopaddmobile {
    padding: 0;
}

@media (max-width: 768px) {
    .container {
        padding: 0 10px;
    }
    
    .container.nopaddmobile {
        padding: 0;
    }
}

/* ================================================ */
/* HEADER MELHORADO */
/* ================================================ */

.header-interna {
    background: var(--white);
    box-shadow: var(--shadow-sm);
    margin: 0;
    width: 100%;
}

.locked-bar {
    padding: 15px 20px;
    background: var(--gradient-primary);
}

.holder-interna {
    padding: 0;
    margin: 0;
}

.avatar .holder {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
    border: 3px solid var(--white);
    box-shadow: var(--shadow-md);
    transition: var(--transition);
}

.avatar .holder:hover {
    transform: scale(1.05);
    box-shadow: var(--shadow-lg);
}

.avatar .holder img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* ================================================ */
/* BREADCRUMB E TÍTULO MODERNOS */
/* ================================================ */

.title-icon {
    margin: 20px 0 10px 0;
}

.title-icon span {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary-color);
    background: var(--white);
    padding: 15px 25px;
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
    display: inline-block;
}

.bread-box {
    background: var(--white);
    padding: 12px 20px;
    margin: 0 0 20px 0;
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
}

.bread {
    font-size: 14px;
    color: var(--dark-gray);
}

.bread a {
    color: var(--primary-color);
    text-decoration: none;
    transition: var(--transition);
}

.bread a:hover {
    color: var(--secondary-color);
    text-decoration: underline;
}

.bread span {
    margin: 0 8px;
    color: var(--medium-gray);
}

/* ================================================ */
/* BARRA DE BUSCA MODERNA */
/* ================================================ */

.search-bar-mobile {
    margin: 15px;
    padding: 0;
}

.search-bar-mobile form {
    background: var(--white);
    border-radius: 25px;
    box-shadow: var(--shadow-sm);
    padding: 5px;
    display: flex;
    align-items: center;
    transition: var(--transition);
    border: 2px solid transparent;
}

.search-bar-mobile form:focus-within {
    box-shadow: var(--shadow-md);
    transform: translateY(-1px);
    border-color: var(--accent-color);
}

.search-bar-mobile input[type="text"] {
    border: none;
    background: transparent;
    padding: 12px 15px;
    flex: 1;
    font-size: 16px;
    outline: none;
    color: var(--dark-gray);
}

.search-bar-mobile input[type="text"]::placeholder {
    color: var(--medium-gray);
    font-weight: 400;
}

.search-bar-mobile button {
    background: var(--gradient-primary);
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--white);
    transition: var(--transition);
    margin-right: 5px;
}

.search-bar-mobile button:hover {
    transform: scale(1.1);
    box-shadow: var(--shadow-md);
}

.search-bar-mobile button i {
    font-size: 16px;
}

/* ================================================ */
/* MENU DE CATEGORIAS HORIZONTAL MELHORADO */
/* ================================================ */

.tv-infinite {
    background: var(--white);
    border-radius: var(--border-radius-sm);
    box-shadow: var(--shadow-sm);
    margin: 15px;
    padding: 5px;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.tv-infinite::-webkit-scrollbar {
    display: none;
}

.tv-infinite-menu {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 5px;
}

.tv-infinite-menu a {
    display: inline-block;
    padding: 12px 20px;
    background: var(--light-gray);
    color: var(--dark-gray);
    text-decoration: none;
    border-radius: 20px;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
    white-space: nowrap;
    border: 2px solid transparent;
    text-transform: capitalize;
}

.tv-infinite-menu a:hover {
    background: var(--accent-color);
    color: var(--white);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.tv-infinite-menu a.active {
    background: var(--gradient-primary);
    color: var(--white);
    border-color: var(--primary-color);
    box-shadow: var(--shadow-sm);
}

/* ================================================ */
/* ÁREA DE PRODUTOS MODERNA */
/* ================================================ */

.categorias {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-sm);
    margin: 15px;
    padding: 20px;
    min-height: 400px;
}

.categoria {
    padding: 0;
}

/* Header da categoria com contador e filtros */
.categoria .row:first-child {
    background: var(--light-gray);
    border-radius: var(--border-radius-sm);
    padding: 15px 20px;
    margin: 0 0 20px 0;
    border: 1px solid var(--medium-gray);
}

.counter {
    font-size: 24px;
    font-weight: 700;
    color: var(--primary-color);
    margin-right: 8px;
}

.title {
    font-size: 14px;
    color: var(--dark-gray);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Filtro de ordenação */
.filter-select {
    position: relative;
}

.filter-select .outside {
    color: var(--primary-color);
    font-size: 18px;
    margin-right: 8px;
    vertical-align: middle;
}

.fake-select {
    position: relative;
    display: inline-block;
}

.fake-select select {
    appearance: none;
    background: var(--white);
    border: 2px solid var(--medium-gray);
    border-radius: var(--border-radius-sm);
    padding: 8px 35px 8px 12px;
    font-size: 14px;
    font-weight: 600;
    color: var(--dark-gray);
    cursor: pointer;
    transition: var(--transition);
    outline: none;
}

.fake-select select:hover,
.fake-select select:focus {
    border-color: var(--primary-color);
    box-shadow: var(--shadow-sm);
}

.fake-select i {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--primary-color);
    pointer-events: none;
    font-size: 12px;
}

/* ================================================ */
/* GRID DE PRODUTOS MELHORADO */
/* ================================================ */

.produtos {
    margin-top: 20px;
}

.tv-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 20px;
    padding: 0;
}

@media (max-width: 768px) {
    .tv-grid {
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: 15px;
    }
}

@media (max-width: 480px) {
    .tv-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
}

.produto {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    transition: var(--transition);
    border: 1px solid var(--medium-gray);
    position: relative;
}

.produto:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
    border-color: var(--accent-color);
}

.produto a {
    display: block;
    text-decoration: none;
    color: inherit;
    height: 100%;
}

/* Imagem do produto */
.produto .capa {
    width: 100%;
    height: 200px;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-color: var(--light-gray);
    border-radius: var(--border-radius) var(--border-radius) 0 0;
    position: relative;
    overflow: hidden;
}

@media (max-width: 768px) {
    .produto .capa {
        height: 150px;
    }
}

.produto .capa::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
    transition: var(--transition);
}

.produto:hover .capa::after {
    background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.2) 100%);
}

/* Informações do produto */
.produto .nome {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: var(--dark-gray);
    padding: 15px 15px 8px 15px;
    line-height: 1.4;
    min-height: 50px;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
}

@media (max-width: 768px) {
    .produto .nome {
        font-size: 14px;
        padding: 12px 12px 6px 12px;
        min-height: 42px;
    }
}

/* Preços */
.produto .valor_anterior {
    display: block;
    font-size: 12px;
    color: var(--medium-gray);
    text-decoration: line-through;
    padding: 0 15px;
    margin-bottom: 2px;
}

.produto .valor_anterior.invisible {
    visibility: hidden;
    height: 16px;
}

.produto .apenas {
    display: block;
    font-size: 11px;
    color: var(--medium-gray);
    padding: 0 15px;
    margin-bottom: 2px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
}

.produto .valor {
    display: block;
    font-size: 18px;
    font-weight: 700;
    color: var(--success-color);
    padding: 0 15px 10px 15px;
}

@media (max-width: 768px) {
    .produto .valor {
        font-size: 16px;
        padding: 0 12px 8px 12px;
    }
}

/* Botão de ação */
.produto .detalhes {
    background: var(--gradient-primary);
    color: var(--white);
    padding: 12px 15px;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: auto;
}

.produto .detalhes:hover {
    background: var(--secondary-color);
}

.produto .detalhes.sem-estoque {
    background: var(--danger-color);
    cursor: not-allowed;
}

.produto .detalhes i {
    font-size: 16px;
}

@media (max-width: 768px) {
    .produto .detalhes {
        padding: 10px 12px;
        font-size: 12px;
    }
    
    .produto .detalhes i {
        font-size: 14px;
    }
}

/* ================================================ */
/* PAGINAÇÃO MODERNA */
/* ================================================ */

.paginacao {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-sm);
    margin: 20px 15px;
    padding: 20px;
    text-align: center;
}

.pagination {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    padding: 0;
    list-style: none;
}

.page-item .page-link {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: var(--light-gray);
    border: 2px solid transparent;
    border-radius: 50%;
    color: var(--dark-gray);
    text-decoration: none;
    font-weight: 600;
    transition: var(--transition);
}

.page-item .page-link:hover {
    background: var(--accent-color);
    color: var(--white);
    border-color: var(--primary-color);
    transform: translateY(-2px);
    box-shadow: var(--shadow-sm);
}

.page-item.active .page-link {
    background: var(--gradient-primary);
    color: var(--white);
    border-color: var(--primary-color);
    box-shadow: var(--shadow-sm);
}

.pagination-back .page-link,
.pagination-next .page-link {
    background: var(--primary-color);
    color: var(--white);
}

.pagination-back .page-link:hover,
.pagination-next .page-link:hover {
    background: var(--secondary-color);
    transform: translateY(-2px) scale(1.1);
}

/* ================================================ */
/* MENSAGEM DE ERRO/VAZIO */
/* ================================================ */

.nulled {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-sm);
    padding: 60px 20px;
    text-align: center;
    margin: 20px 15px;
    border: 2px dashed var(--medium-gray);
}

.nulled-content {
    font-size: 20px;
    font-weight: 600;
    color: var(--dark-gray);
    display: block;
    margin-bottom: 15px;
}

.nulled-content::before {
    content: '⚠️';
    font-size: 40px;
    display: block;
    margin-bottom: 15px;
}

/* ================================================ */
/* RESPONSIVIDADE GERAL */
/* ================================================ */

@media (max-width: 768px) {
    .title-icon {
        margin: 15px;
    }
    
    .title-icon span {
        font-size: 22px;
        padding: 12px 20px;
    }
    
    .bread-box {
        margin: 0 15px 15px 15px;
        padding: 10px 15px;
    }
    
    .categorias {
        margin: 10px;
        padding: 15px;
        border-radius: var(--border-radius-sm);
    }
    
    .tv-infinite {
        margin: 10px;
    }
    
    .paginacao {
        margin: 15px 10px;
        padding: 15px;
    }
    
    .nulled {
        margin: 15px 10px;
        padding: 40px 15px;
    }
}

/* ================================================ */
/* MELHORIAS NA FONTE E TIPOGRAFIA */
/* ================================================ */

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

body, html {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

h1, h2, h3, h4, h5, h6 {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-weight: 700;
}

/* ================================================ */
/* AJUSTES FINAIS E POLIMENTOS */
/* ================================================ */

/* Smooth scrolling */
html {
    scroll-behavior: smooth;
}

/* Melhor foco para acessibilidade */
*:focus {
    outline: 2px solid var(--accent-color);
    outline-offset: 2px;
}

/* Animações suaves */
@media (prefers-reduced-motion: reduce) {
    * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
}

/* Preloader para imagens */
img {
    transition: opacity 0.3s ease;
}

img:not([src]) {
    opacity: 0;
}

/* Fallback para navegadores antigos */
@supports not (display: grid) {
    .tv-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .tv-grid > div {
        flex: 1 1 280px;
        max-width: calc(50% - 10px);
    }
    
    @media (max-width: 768px) {
        .tv-grid > div {
            max-width: calc(50% - 7.5px);
        }
    }
}
</style>

<div class="sceneElement">
    <!-- ************************************************ -->
    <!-- CABEÇALHO MOBILE COM LOGO DO ESTABELECIMENTO -->
    <!-- ************************************************ -->
    <div class="header-interna">
        <div class="locked-bar visible-xs visible-sm">
            <div class="avatar">
                <div class="holder">
                    <a href="<?php echo $app['url']; ?>">
                        <img src="<?php echo $app['avatar']; ?>" alt="<?php echo $app['title']; ?>"/>
                    </a>
                </div>    
            </div>
        </div>
        <div class="holder-interna visible-xs visible-sm"></div>
    </div>

    <div class="minfit">
        <?php if($has_content) { ?>
            <!-- ************************************************ -->
            <!-- CONTEÚDO QUANDO A CATEGORIA EXISTE -->
            <!-- ************************************************ -->
            <div class="middle">
                <div class="container nopaddmobile">
                    <!-- TÍTULO E BREADCRUMB (CAMINHO DE NAVEGAÇÃO) -->
                    <div class="row rowtitle hidden-xs hidden-sm">
                        <?php 
                        if(!$busca) { 
                            // Exibição para navegação de categorias
                            $categoria_name = htmlclean(data_info("categorias", $categoria, "nome"));
                            if(!$categoria_name) { 
                                $categoria_name = "Todas as Categorias"; 
                            }
                        ?>
                            <div class="col-md-12">
                                <div class="title-icon">
                                    <span><?php echo $categoria_name; ?></span>
                                </div>
                                <div class="bread-box">
                                    <div class="bread">
                                        <a href="<?php echo $app['url']; ?>"><i class="lni lni-home"></i></a>
                                        <span>/</span>
                                        <a href="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata; ?>">Categorias</a>
                                        <span>/</span>
                                        <a href="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata; ?>"><?php echo $categoria_name; ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php } else { ?>
                            <!-- Exibição para resultados de busca -->
                            <div class="col-md-12">
                                <div class="title-icon">
                                    <span>Resultados da Busca</span>
                                </div>
                                <div class="bread-box">
                                    <div class="bread">
                                        <a href="<?php echo $app['url']; ?>"><i class="lni lni-home"></i></a>
                                        <span>/</span>
                                        <a href="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata; ?>">Buscar: <strong><?php echo htmlclean($busca); ?></strong></a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- BARRA DE BUSCA PARA MOBILE -->
                    <div class="row visible-xs visible-sm">
                        <div class="col-md-12">
                            <div class="search-bar-mobile">
                                <form class="align-middle" method="GET">
                                    <input type="text" name="busca" placeholder="Digite sua busca..." value="<?php echo htmlclean($_GET['busca']); ?>"/>
                                    <input type="hidden" name="categoria" value="<?php echo $categoria; ?>"/>
                                    <button type="submit">
                                        <i class="lni lni-search-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- MENU DE NAVEGAÇÃO ENTRE CATEGORIAS -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="tv-infinite">
                                <div class="tv-infinite-menu">
                                    <?php
                                    // Preparação dos parâmetros para manter filtros ao trocar de categoria
                                    $query_params = "";
                                    if($busca) {
                                        $query_params .= "&busca=".$busca;
                                    }
                                    if($filtro) {
                                        $query_params .= "&filtro=".$filtro;
                                    }
                                    ?>
                                    <a class="<?php if(!$categoria){ echo 'active'; } ?>" href="<?php echo $app['url']; ?>/categoria<?php echo $query_params ? '?'.substr($query_params, 1) : ''; ?>">
                                        <i class="lni lni-grid-alt"></i> Todas
                                    </a>
                                    <?php        
                                    // Listagem das categorias disponíveis
                                    $query_categorias = mysqli_query($db_con, "SELECT * FROM categorias WHERE rel_estabelecimentos_id = '$app_id' AND visible = '1' AND status = '1' ORDER BY ordem ASC");
                                    while($data_categoria = mysqli_fetch_array($query_categorias)) {
                                    ?>
                                    <a class="<?php if($data_categoria['id'] == $categoria){ echo 'active'; } ?>" href="<?php echo $app['url']; ?>/categoria/<?php echo $data_categoria['id']; ?><?php echo $query_params ? '?'.substr($query_params, 1) : ''; ?>">
                                        <?php echo htmlclean($data_categoria['nome']); ?>
                                    </a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ************************************************ -->
                    <!-- LISTAGEM DE PRODUTOS DA CATEGORIA -->
                    <!-- ************************************************ -->
                    <div class="categorias no-bottom-mobile">
                        <?php
                        // Configurações de paginação
                        $limite = 12; // Produtos por página
                        $pagina = $_GET["pagina"] == "" ? 1 : $_GET["pagina"];
                        $inicio = ($pagina * $limite) - $limite;

                        // Construção da consulta SQL base
                        $query = "";
                        $query .= "SELECT * FROM produtos ";
                        $query .= "WHERE 1=1 ";

                        // Filtros aplicados à consulta
                        if($categoria) {
                          $query .= "AND rel_categorias_id = '$categoria' ";
                        }

                        if($busca) {
                          $query .= "AND nome LIKE '%$busca%' ";
                        }

                        $query .= "AND status = '1' AND visible = '1' ";
                        $query .= "AND rel_estabelecimentos_id = '$app_id' ";

                        $query_full = $query; // Versão completa para contagem

                        // Ordenação baseada no filtro selecionado
                        if($filtro == "1" OR !$filtro) {
                            // Ordenação por relevância (mais recentes primeiro)
                            $query .= "ORDER BY id DESC LIMIT $inicio,$limite";
                        }

                        if($filtro == "2") {
                            // Ordenação por preço crescente
                            $query .= "ORDER BY valor_promocional ASC LIMIT $inicio,$limite";
                        }

                        if($filtro == "3") {
                            // Ordenação por preço decrescente
                            $query .= "ORDER BY valor_promocional DESC LIMIT $inicio,$limite";
                        }

                        if($filtro == "4") {
                            // Filtro de ofertas
                            $query .= "AND oferta = '1' ";
                            $query .= "ORDER BY valor_promocional ASC LIMIT $inicio,$limite";
                        }

                        // Execução das consultas e cálculos de paginação
                        $sql = mysqli_query($db_con, $query);
                        $total_results = mysqli_num_rows($sql);
                        $sql_full = mysqli_query($db_con, $query_full);
                        $total_results_full = mysqli_num_rows($sql_full);
                        
                        // CORREÇÃO: Cálculo correto do total de páginas
                        $total_paginas = ceil($total_results_full / $limite);

                        // Validação da página atual
                        if(!$pagina || !is_numeric($pagina) || $pagina < 1) {
                            $pagina = 1;
                        } else if($pagina > $total_paginas && $total_paginas > 0) {
                            // Se a página solicitada for maior que o total, redirecionar para a última
                            header("Location: ".$app['url']."/categoria/".($inparametro ? $inparametro : "")."/?pagina=".$total_paginas.$getdata);
                            exit;
                        }
                        ?>

                        <div class="categoria no-bottom-mobile">
                            <!-- CABEÇALHO COM CONTADOR E FILTRO DE ORDENAÇÃO -->
                            <div class="row">
                                <!-- Contador de itens encontrados -->
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <div style="display: flex; align-items: center; gap: 5px;">
                                        <span class="counter"><?php echo number_format($total_results_full, 0, ',', '.'); ?></span>
                                        <span class="title"><?php echo $total_results_full == 1 ? 'Item encontrado' : 'Itens encontrados'; ?></span>
                                    </div>
                                </div>
                                
                                <!-- Seletor de filtros/ordenação -->
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <div class="filter-select pull-right">
                                        <i class="outside lni lni-funnel"></i>
                                        <div class="fake-select">
                                            <select name="filtro" onchange="window.location.href = this.value">
                                                <option <?php if($_GET['filtro'] == "1" || !$_GET['filtro']) { echo "SELECTED"; }; ?> value="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata_unfilter; ?>&filtro=1">Mais Recentes</option>
                                                <option <?php if($_GET['filtro'] == "2") { echo "SELECTED"; }; ?> value="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata_unfilter; ?>&filtro=2">Menor Preço</option>
                                                <option <?php if($_GET['filtro'] == "3") { echo "SELECTED"; }; ?> value="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata_unfilter; ?>&filtro=3">Maior Preço</option>
                                                <option <?php if($_GET['filtro'] == "4") { echo "SELECTED"; }; ?> value="<?php echo $app['url']; ?>/categoria/<?php echo $inparametro; ?><?php echo $getdata_unfilter; ?>&filtro=4">Em Oferta</option>
                                            </select>
                                            <i class="lni lni-chevron-down"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- GRID DE PRODUTOS -->
                            <div class="produtos">
                                <div class="tv-grid">
                                    <?php
                                    // Se não houver produtos nesta página, exibir mensagem
                                    if($total_results == 0 && $total_results_full == 0) {
                                        echo '<div style="grid-column: 1/-1; text-align: center; padding: 60px 20px;">';
                                        echo '<div style="font-size: 48px; margin-bottom: 20px;">🔍</div>';
                                        echo '<h3 style="color: var(--dark-gray); margin-bottom: 10px;">Nenhum produto encontrado</h3>';
                                        if($busca) {
                                            echo '<p style="color: var(--medium-gray);">Sua busca por "<strong>'.htmlclean($busca).'</strong>" não retornou resultados.</p>';
                                        } else {
                                            echo '<p style="color: var(--medium-gray);">Esta categoria não possui produtos disponíveis no momento.</p>';
                                        }
                                        echo '<a href="'.$app['url'].'" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">← Voltar ao início</a>';
                                        echo '</div>';
                                    }
                                    
                                    $count_produtos = 0; // Contador para validar número de produtos exibidos
                                    
                                    while($data_produtos = mysqli_fetch_array($sql)) {
                                        // Verificação completa para produtos com dados incompletos
                                        if(!$data_produtos['nome'] || !$data_produtos['id']) {
                                            error_log("Produto incompleto: ID={$data_produtos['id']}, Nome={$data_produtos['nome']}");
                                            continue; // Pula produtos com dados incompletos
                                        }
                                        
                                        $count_produtos++; // Incrementa contador de produtos válidos
                                        
                                        // Define o valor final (oferta ou preço normal)
                                        $valor_final = ($data_produtos['oferta'] == "1") ? $data_produtos['valor_promocional'] : $data_produtos['valor'];
                                        
                                        // Garante que o valor_final é um número válido
                                        $valor_final = is_numeric($valor_final) ? $valor_final : 0;
                                        
                                        // Fallback para imagem do produto
                                        $imagem_produto = $data_produtos['destaque'] ?: '_core/_cdn/img/no-image.jpg';
                                    ?>
                                    <div>
                                        <div class="produto">
                                            <a href="<?php echo $app['url']; ?>/produto/<?php echo $data_produtos['id']; ?>" title="<?php echo htmlclean($data_produtos['nome']); ?>">
                                                <!-- Imagem do produto com fallback para imagens não disponíveis -->
                                                <div class="capa" style="background-image: url(<?php echo thumber($imagem_produto, 450); ?>);"></div>
                                                
                                                <span class="nome"><?php echo htmlclean($data_produtos['nome']); ?></span>
                                                
                                                <?php if($valor_final > 0) { ?>
                                                    <?php if($data_produtos['oferta'] == "1" && $data_produtos['valor'] > 0) { ?>
                                                        <!-- Exibição de preço promocional com valor original riscado -->
                                                        <span class="valor_anterior">De: R$ <?php echo dinheiro($data_produtos['valor'], "BR"); ?></span>
                                                    <?php } else { ?>
                                                        <span class="valor_anterior invisible">&nbsp;</span>
                                                    <?php } ?>
                                                    <span class="apenas">Por apenas</span>
                                                    <span class="valor">R$ <?php echo dinheiro($valor_final, "BR"); ?></span>
                                                    
                                                    <!-- Verificação de disponibilidade em estoque -->
                                                    <?php if($data_produtos['estoque'] == 1 || ($data_produtos['estoque'] == 2 && $data_produtos['posicao'] > 0)) { ?>
                                                        <div class="detalhes">
                                                            <i class="lni lni-shopping-basket"></i> 
                                                            <span>Comprar</span>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="detalhes sem-estoque">
                                                            <i class="lni lni-close"></i> 
                                                            <span>Sem Estoque</span>
                                                        </div>
                                                    <?php } ?>
                                                <?php } else { ?>
                                                    <!-- Produto com preço variável/opcionais -->
                                                    <span class="valor_anterior invisible">&nbsp;</span>
                                                    <span class="apenas">Este item possui</span>
                                                    <span class="valor" style="color: var(--primary-color); font-size: 14px;">Opcionais disponíveis</span>
                                                    <div class="detalhes">
                                                        <i class="lni lni-list"></i> 
                                                        <span>Ver Opções</span>
                                                    </div>
                                                <?php } ?>
                                            </a>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    
                                    <?php 
                                    // Log para diagnóstico
                                    if($count_produtos != $total_results) {
                                        error_log("Discrepância na contagem de produtos: Esperado {$total_results}, Exibido {$count_produtos}");
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ************************************************ -->
                    <!-- CONTROLES DE PAGINAÇÃO -->
                    <!-- ************************************************ -->
                    <?php if($total_paginas > 1) { ?>
                    <div class="paginacao">
                        <ul class="pagination">
                            <?php
                            // Construção correta do path de paginação
                            $paginationpath = "categoria";
                            if($inparametro) {
                                $paginationpath .= "/".$inparametro;
                            }
                            
                            // Parâmetros de query string para manter filtros
                            $query_string_params = array();
                            if($busca) $query_string_params[] = "busca=".$busca;
                            if($filtro) $query_string_params[] = "filtro=".$filtro;
                            $query_string = !empty($query_string_params) ? "&".implode("&", $query_string_params) : "";
                            
                            // Botão para página anterior
                            if($pagina > 1) {
                                $back = $pagina-1;
                                echo '<li class="page-item pagination-back">';
                                echo '<a class="page-link" href="'.$app['url'].'/'.$paginationpath.'?pagina='.$back.$query_string.'" title="Página anterior">';
                                echo '<i class="lni lni-chevron-left"></i>';
                                echo '</a></li>';
                            }
                     
                            // Exibição da página anterior à atual
                            if($pagina > 1) {
                                echo '<li class="page-item pages-before">';
                                echo '<a class="page-link" href="'.$app['url'].'/'.$paginationpath.'?pagina='.($pagina-1).$query_string.'" title="Página '.($pagina-1).'">';
                                echo ($pagina-1);
                                echo '</a></li>';
                            }

                            // Exibição da página atual
                            echo '<li class="page-item active">';
                            echo '<a class="page-link" href="'.$app['url'].'/'.$paginationpath.'?pagina='.$pagina.$query_string.'" title="Página atual">';
                            echo $pagina;
                            echo '</a></li>';

                            // Exibição da página posterior à atual
                            if($pagina < $total_paginas) {
                                echo '<li class="page-item pages-after">';
                                echo '<a class="page-link" href="'.$app['url'].'/'.$paginationpath.'?pagina='.($pagina+1).$query_string.'" title="Página '.($pagina+1).'">';
                                echo ($pagina+1);
                                echo '</a></li>';
                            }

                            // Botão para próxima página
                            if($pagina < $total_paginas) {
                                $next = $pagina+1;
                                echo '<li class="page-item pagination-next">';
                                echo '<a class="page-link" href="'.$app['url'].'/'.$paginationpath.'?pagina='.$next.$query_string.'" title="Próxima página">';
                                echo '<i class="lni lni-chevron-right"></i>';
                                echo '</a></li>';
                            }
                            ?>
                        </ul>
                        
                        <!-- Informações adicionais de paginação -->
                        <div style="text-align: center; margin-top: 15px; color: var(--medium-gray); font-size: 14px;">
                            Página <?php echo $pagina; ?> de <?php echo $total_paginas; ?> 
                            (<?php echo number_format($total_results_full, 0, ',', '.'); ?> <?php echo $total_results_full == 1 ? 'produto' : 'produtos'; ?> no total)
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        <?php } else { ?>
            <!-- ************************************************ -->
            <!-- MENSAGEM PARA CATEGORIA INVÁLIDA -->
            <!-- ************************************************ -->
            <div class="middle">
                <div class="container nopaddmobile">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="nulled">
                                <span class="nulled-content">Categoria não encontrada</span>
                                <p style="color: var(--medium-gray); margin-bottom: 20px;">A categoria solicitada não existe ou foi removida.</p>
                                <a href="<?php echo $app['url']; ?>" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">
                                    <i class="lni lni-arrow-left"></i> Voltar ao início
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php 
// ************************************************
// CARREGAMENTO DO RODAPÉ
// ************************************************
$system_footer .= "";
include($virtualpath.'/_layout/rdp.php');
include($virtualpath.'/_layout/footer.php');
?>

<!-- ************************************************ -->
<!-- SCRIPTS JAVASCRIPT MODERNOS -->
<!-- ************************************************ -->
<script>
// Aguarda o carregamento completo do DOM
document.addEventListener('DOMContentLoaded', function() {
    
    // ================================================
    // CENTRALIZAÇÃO SUAVE DA CATEGORIA ATIVA NO MENU
    // ================================================
    const activeCategory = document.querySelector('.tv-infinite-menu .active');
    const menuContainer = document.querySelector('.tv-infinite');
    
    if (activeCategory && menuContainer) {
        // Calcula a posição para centralizar o item ativo
        const containerWidth = menuContainer.offsetWidth;
        const activeWidth = activeCategory.offsetWidth;
        const activePosition = activeCategory.offsetLeft;
        const scrollPosition = activePosition - (containerWidth / 2) + (activeWidth / 2);
        
        // Animação suave de scroll
        menuContainer.scrollTo({
            left: Math.max(0, scrollPosition),
            behavior: 'smooth'
        });
    }
    
    // ================================================
    // MELHORIAS NA EXPERIÊNCIA DE NAVEGAÇÃO
    // ================================================
    
    // Carregamento lazy para imagens de produtos
    const productImages = document.querySelectorAll('.produto .capa');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const imageDiv = entry.target;
                    const backgroundImage = window.getComputedStyle(imageDiv).backgroundImage;
                    
                    if (backgroundImage && backgroundImage !== 'none') {
                        // Adiciona uma classe para indicar que a imagem foi carregada
                        imageDiv.classList.add('loaded');
                    }
                    
                    observer.unobserve(imageDiv);
                }
            });
        });
        
        productImages.forEach(img => imageObserver.observe(img));
    }
    
    // ================================================
    // FEEDBACK VISUAL PARA INTERAÇÕES
    // ================================================
    
    // Efeito de feedback nos produtos
    const produtos = document.querySelectorAll('.produto');
    produtos.forEach(produto => {
        produto.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        
        produto.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(-5px)';
        });
    });
    
    // ================================================
    // OTIMIZAÇÃO DO FILTRO DE ORDENAÇÃO
    // ================================================
    
    const filtroSelect = document.querySelector('select[name="filtro"]');
    if (filtroSelect) {
        filtroSelect.addEventListener('change', function() {
            // Adiciona loading state
            this.style.opacity = '0.7';
            this.style.pointerEvents = 'none';
            
            // Adiciona um indicador de carregamento
            const loadingText = document.createElement('div');
            loadingText.textContent = 'Carregando...';
            loadingText.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: var(--white); padding: 20px; border-radius: 8px; box-shadow: var(--shadow-lg); z-index: 1000;';
            document.body.appendChild(loadingText);
            
            // Redireciona após um breve delay para melhor UX
            setTimeout(() => {
                window.location.href = this.value;
            }, 300);
        });
    }
    
    // ================================================
    // SUPORTE A GESTOS DE TOQUE (MOBILE)
    // ================================================
    
    let touchStartX = 0;
    let touchEndX = 0;
    
    const handleSwipe = () => {
        const swipeThreshold = 50;
        const swipeDistance = touchEndX - touchStartX;
        
        if (Math.abs(swipeDistance) > swipeThreshold) {
            const menuContainerSwipe = document.querySelector('.tv-infinite');
            if (menuContainerSwipe) {
                if (swipeDistance > 0) {
                    // Swipe para direita - rola para esquerda
                    menuContainerSwipe.scrollLeft -= 100;
                } else {
                    // Swipe para esquerda - rola para direita
                    menuContainerSwipe.scrollLeft += 100;
                }
            }
        }
    };
    
    const menuContainerTouch = document.querySelector('.tv-infinite');
    if (menuContainerTouch) {
        menuContainerTouch.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        });
        
        menuContainerTouch.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });
    }
    
    // ================================================
    // OTIMIZAÇÃO DE PERFORMANCE
    // ================================================
    
    // Throttle para scroll events
    function throttle(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Indicador de scroll no menu de categorias
    const updateScrollIndicator = throttle(() => {
        const menuContainerScroll = document.querySelector('.tv-infinite');
        if (menuContainerScroll) {
            const isScrollable = menuContainerScroll.scrollWidth > menuContainerScroll.clientWidth;
            const isAtEnd = menuContainerScroll.scrollLeft >= (menuContainerScroll.scrollWidth - menuContainerScroll.clientWidth - 5);
            const isAtStart = menuContainerScroll.scrollLeft <= 5;
            
            // Adiciona classes para indicação visual
            menuContainerScroll.classList.toggle('scroll-end', isAtEnd);
            menuContainerScroll.classList.toggle('scroll-start', isAtStart);
            menuContainerScroll.classList.toggle('scrollable', isScrollable);
        }
    }, 16);
    
    if (menuContainer) {
        menuContainer.addEventListener('scroll', updateScrollIndicator);
        window.addEventListener('resize', updateScrollIndicator);
        updateScrollIndicator(); // Executa inicialmente
    }
});

// ================================================
// FALLBACK PARA NAVEGADORES MAIS ANTIGOS
// ================================================

// Fallback para o event listener se DOMContentLoaded não estiver disponível
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeScript);
} else {
    initializeScript();
}

function initializeScript() {
    // Código de inicialização já está acima no DOMContentLoaded
    console.log('🛍️ Página de categoria carregada com sucesso!');
}

// ================================================
// ANALYTICS E TRACKING (OPCIONAL)
// ================================================

// Função para track de eventos (pode ser integrada com Google Analytics, etc.)
function trackEvent(action, category = 'Categoria', label = '') {
    if (typeof gtag !== 'undefined') {
        gtag('event', action, {
            event_category: category,
            event_label: label
        });
    }
    // console.log(`Event tracked: ${action} - ${category} - ${label}`);
}

// Track de cliques em produtos
document.addEventListener('click', function(e) {
    const productLink = e.target.closest('.produto a');
    if (productLink) {
        const productName = productLink.querySelector('.nome')?.textContent || 'Unknown';
        trackEvent('product_click', 'Produto', productName);
    }
    
    const categoryLink = e.target.closest('.tv-infinite-menu a');
    if (categoryLink) {
        const categoryName = categoryLink.textContent.trim();
        trackEvent('category_change', 'Navegação', categoryName);
    }
});
</script>

<!-- CSS adicional para indicadores de scroll (carregado após o CSS principal) -->
<style>
/* Indicadores visuais para scroll do menu */
.tv-infinite.scrollable::before,
.tv-infinite.scrollable::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    width: 20px;
    pointer-events: none;
    z-index: 1;
    transition: opacity 0.3s ease;
}

.tv-infinite.scrollable::before {
    left: 0;
    background: linear-gradient(to right, var(--white), transparent);
    opacity: 0;
}

.tv-infinite.scrollable::after {
    right: 0;
    background: linear-gradient(to left, var(--white), transparent);
    opacity: 1;
}

.tv-infinite.scroll-start::before {
    opacity: 0;
}

.tv-infinite.scroll-end::after {
    opacity: 0;
}

.tv-infinite:not(.scroll-start)::before {
    opacity: 1;
}

/* Animação de carregamento para imagens */
.produto .capa {
    position: relative;
    overflow: hidden;
}

.produto .capa::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shimmer 1.5s infinite;
}

.produto .capa.loaded::before {
    display: none;
}

@keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

/* Melhorias de acessibilidade */
.produto:focus-within {
    outline: 2px solid var(--accent-color);
    outline-offset: 2px;
}

.page-link:focus {
    box-shadow: var(--shadow-md), 0 0 0 2px var(--accent-color);
}

/* Responsividade adicional */
@media (max-width: 480px) {
    .pagination {
        gap: 4px;
    }
    
    .page-item .page-link {
        width: 35px;
        height: 35px;
        font-size: 12px;
    }
}
</style>