<?php
// ************************************************
// CONFIGURAÇÕES INICIAIS E CARREGAMENTO DE RECURSOS
// ************************************************

// Carregando definições do sistema
include($virtualpath.'/_layout/define.php');
include('../../_core/_includes/config.php');

// Configurações globais da aplicação
global $app;
is_active($app['id']);
global $seo_title;

// Captura de parâmetros de busca e categoria
$busca = mysqli_real_escape_string($db_con, $_GET['busca']);
$categoria = mysqli_real_escape_string($db_con, $_GET['categoria']);

// ************************************************
// CONFIGURAÇÕES DE SEO (OTIMIZAÇÃO PARA BUSCADORES)
// ************************************************

$seo_subtitle = $app['title'];
$seo_description = $app['description_clean'];
$seo_keywords = $app['title'].", ".$seo_title;
$seo_image = thumber($app['avatar_clean'], 400);

// ************************************************
// INCLUSÃO DOS ARQUIVOS DE LAYOUT
// ************************************************

$system_header .= "";
include($virtualpath.'/_layout/head.php');
include($virtualpath.'/_layout/top.php');
include($virtualpath.'/_layout/sidebars.php');
include($virtualpath.'/_layout/modal.php');
instantrender();

// Captura URL atual para compartilhamento
$pegaurlx = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<style>
/* ================================================ */
/* MELHORIAS PROFISSIONAIS NO LAYOUT */
/* ================================================ */

/* Variáveis CSS para consistência de cores - Integradas com a cor do estabelecimento */
:root {
    --primary-color: <?php echo $app['cor'] ?: '#2c3e50'; ?>;
    --secondary-color: <?php echo adjust_brightness($app['cor'] ?: '#2c3e50', -30); ?>;
    --success-color: #27ae60;
    --danger-color: #e74c3c;
    --warning-color: #f39c12;
    --light-gray: #ecf0f1;
    --medium-gray: #bdc3c7;
    --dark-gray: #34495e;
    --white: #ffffff;
    --shadow-light: 0 2px 10px rgba(0,0,0,0.1);
    --shadow-medium: 0 4px 20px rgba(0,0,0,0.15);
    --shadow-heavy: 0 8px 30px rgba(0,0,0,0.2);
    --border-radius: 12px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

<?php
// Função PHP para ajustar brilho das cores
function adjust_brightness($hex, $percent) {
    if (!$hex) return '#2c3e50';
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + ($r * $percent / 100)));
    $g = max(0, min(255, $g + ($g * $percent / 100)));
    $b = max(0, min(255, $b + ($b * $percent / 100)));
    
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>

/* ================================================ */
/* REMOÇÃO COMPLETA DE ESPAÇAMENTOS LATERAIS */
/* ================================================ */
* {
    box-sizing: border-box;
}

html, body {
    margin: 0 !important;
    padding: 0 !important;
    overflow-x: hidden;
    width: 100%;
}

.sceneElement {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    padding: 0 !important;
    margin: 0 !important;
    width: 100vw;
    overflow-x: hidden;
}

.container, .container-fluid {
    padding: 0 !important;
    margin: 0 !important;
    max-width: 100% !important;
    width: 100% !important;
}

.container.nopadd {
    padding: 0 !important;
    margin: 0 !important;
}

.row {
    margin: 0 !important;
    padding: 0 !important;
}

.col-xs-12, .col-sm-12, .col-md-12, .col-lg-12 {
    padding: 0 !important;
}

/* Container principal do conteúdo */
.middle.minfit {
    background: transparent;
    padding: 0 !important;
    margin: 0 !important;
    width: 100%;
}

/* ================================================ */
/* MELHORIAS NO CAROUSEL DE BANNERS */
/* ================================================ */
.banners {
    margin: 0;
    padding: 0;
    width: 100%;
}

.banners-container {
    background: var(--white);
    border-radius: 0;
    box-shadow: var(--shadow-light);
    padding: 15px 10px;
    overflow: hidden;
    margin: 0;
    width: 100%;
}

.banners-header {
    text-align: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--light-gray);
}

.banners-title {
    color: var(--primary-color);
    font-size: 20px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin: 0;
}

.banners-title i {
    color: var(--warning-color);
    margin-right: 10px;
}

.carousel-inner .item {
    display: none;
    position: relative;
    width: 100%;
    height: auto;
    text-align: center;
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: var(--shadow-medium);
}

.carousel-inner .item.active {
    display: block;
    opacity: 1;
    transition: opacity 0.5s ease-in-out;
}

.carousel-inner {
    box-shadow: none !important;
    border: none !important;
    overflow: hidden;
    border-radius: var(--border-radius);
    position: relative;
}

.carousel-inner .item img {
    display: block;
    margin: 0 auto;
    width: 100%;
    height: auto;
    transition: transform 0.3s ease;
}

.banner-link:hover img {
    transform: scale(1.02);
}

.carousel-inner {
    transition: transform 0.5s ease-in-out;
}

/* Indicadores melhorados */
.carousel-indicators {
    bottom: 15px;
    margin-bottom: 0;
}

.carousel-indicators li {
    background-color: rgba(255,255,255,0.5);
    border: 2px solid var(--white);
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin: 0 5px;
    transition: var(--transition);
}

.carousel-indicators .active {
    background-color: var(--secondary-color);
    transform: scale(1.2);
}

/* Setas de navegação melhoradas */
.carousel-control {
    display: block !important;
    background: linear-gradient(45deg, rgba(0,0,0,0.6), rgba(0,0,0,0.4)) !important;
    box-shadow: var(--shadow-light) !important;
    border: none;
    color: var(--white);
    font-size: 20px;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    top: 50%;
    transform: translateY(-50%);
    transition: var(--transition);
}

.carousel-control:hover {
    background: linear-gradient(45deg, rgba(0,0,0,0.8), rgba(0,0,0,0.6)) !important;
    transform: translateY(-50%) scale(1.1);
    color: var(--white);
}

.carousel-control.left {
    left: 15px;
}

.carousel-control.right {
    right: 15px;
}

/* ================================================ */
/* MELHORIAS NO CABEÇALHO MOBILE */
/* ================================================ */
.cover {
    border-radius: var(--border-radius) var(--border-radius) 0 0;
    box-shadow: var(--shadow-medium);
    position: relative;
    overflow: hidden;
}

.cover::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.3) 100%);
    pointer-events: none;
}

.avatar .holder {
    border: 4px solid var(--white);
    border-radius: 50%;
    box-shadow: var(--shadow-medium);
    transition: var(--transition);
}

.avatar .holder:hover {
    transform: scale(1.05);
    box-shadow: var(--shadow-heavy);
}

.app-infos {
    background: var(--white);
    border-radius: 0 0 var(--border-radius) var(--border-radius);
    box-shadow: var(--shadow-medium);
    padding: 20px;
    margin-top: -10px;
    position: relative;
    z-index: 2;
}

.app-infos .title {
    font-size: 24px;
    font-weight: 700;
    color: var(--primary-color);
    text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
    margin-bottom: 8px;
    display: block;
}

.app-infos .description {
    color: var(--dark-gray);
    font-size: 14px;
    line-height: 1.6;
    margin-bottom: 15px;
    display: block;
}

/* Melhorias nos botões de status */
.btn {
    border-radius: 25px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: var(--transition);
    border: none;
    box-shadow: var(--shadow-light);
    padding: 8px 20px;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-medium);
}

.btn-success {
    background: linear-gradient(135deg, var(--success-color), #2ecc71);
}

.btn-danger {
    background: linear-gradient(135deg, var(--danger-color), #c0392b);
}

.btn-primary {
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
}

.btn-info {
    background: linear-gradient(135deg, #17a2b8, #138496);
}

/* ================================================ */
/* MELHORIAS NOS BOTÕES DE STATUS */
/* ================================================ */
.status-container {
    background: var(--white);
    border-radius: var(--border-radius);
    padding: 15px;
    box-shadow: var(--shadow-light);
    margin: 15px 0;
}

.status-btn {
    padding: 15px 30px;
    font-size: 16px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    border-radius: 30px;
    border: none;
    box-shadow: var(--shadow-medium);
    transition: var(--transition);
    position: relative;
    overflow: hidden;
}

.status-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}

.status-btn:hover::before {
    left: 100%;
}

.status-btn i {
    margin-right: 8px;
    font-size: 18px;
}

.btn-lg.status-btn {
    min-width: 220px;
}

/* ================================================ */
/* MELHORIAS ADICIONAIS NOS INFO BADGES */
/* ================================================ */
.info-badges {
    display: flex;
    gap: 15px;
    margin: 20px 0;
    flex-wrap: wrap;
}

.info-badge {
    background: linear-gradient(135deg, var(--light-gray), #ddd);
    border-radius: var(--border-radius);
    padding: 15px;
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    flex: 1;
    min-width: 140px;
    text-align: center;
}

.info-badge:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-medium);
    background: linear-gradient(135deg, #e8f4f8, #d4e6f1);
}

.info-badge i {
    font-size: 24px;
    color: var(--secondary-color);
    margin-bottom: 8px;
    display: block;
}

.info-badge span {
    font-size: 12px;
    color: var(--dark-gray);
    font-weight: 600;
    line-height: 1.4;
}

.info-badge a {
    color: var(--dark-gray);
    text-decoration: none;
    transition: var(--transition);
}

.info-badge a:hover {
    color: var(--secondary-color);
}

/* ================================================ */
/* MELHORIAS NOS BOTÕES DE INSTALAÇÃO PWA */
/* ================================================ */
.install-buttons {
    background: var(--white);
    border-radius: var(--border-radius);
    padding: 15px;
    box-shadow: var(--shadow-light);
    margin: 20px 0;
}

/* ================================================ */
/* MELHORIAS NA BARRA DE BUSCA */
/* ================================================ */
.search-bar-mobile {
    margin: 10px 5px;
    width: calc(100% - 10px);
}

.search-bar-mobile form {
    background: var(--white);
    border-radius: 25px;
    box-shadow: var(--shadow-light);
    padding: 5px;
    display: flex;
    align-items: center;
    transition: var(--transition);
    width: 100%;
}

.search-bar-mobile form:focus-within {
    box-shadow: var(--shadow-medium);
    transform: translateY(-1px);
}

.search-bar-mobile input[type="text"] {
    border: none;
    background: transparent;
    padding: 12px 15px;
    flex: 1;
    font-size: 14px;
    outline: none;
    color: var(--dark-gray);
}

.search-bar-mobile input[type="text"]::placeholder {
    color: var(--medium-gray);
}

.search-bar-mobile button {
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: var(--white);
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
}

.search-bar-mobile button:hover {
    transform: scale(1.1);
    box-shadow: var(--shadow-medium);
}

/* ================================================ */
/* MELHORIAS NO MENU DE CATEGORIAS */
/* ================================================ */
.tv-infinite-menu {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-light);
    padding: 10px;
    display: flex;
    overflow-x: auto;
    gap: 10px;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.tv-infinite-menu::-webkit-scrollbar {
    display: none;
}

.tv-infinite-menu a {
    white-space: nowrap;
    padding: 10px 20px;
    border-radius: 20px;
    text-decoration: none;
    color: var(--dark-gray);
    font-weight: 600;
    font-size: 13px;
    transition: var(--transition);
    background: var(--light-gray);
    border: 2px solid transparent;
}

.tv-infinite-menu a:hover {
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
    color: var(--white);
    transform: translateY(-2px);
    box-shadow: var(--shadow-light);
}

.tv-infinite-menu a.active {
    background: linear-gradient(135deg, var(--primary-color), var(--dark-gray));
    color: var(--white);
    box-shadow: var(--shadow-medium);
}

/* ================================================ */
/* MELHORIAS NAS CATEGORIAS E PRODUTOS */
/* ================================================ */
.categoria {
    background: var(--white);
    border-radius: 0;
    box-shadow: var(--shadow-light);
    margin: 0 0 10px 0;
    padding: 15px 10px;
    transition: var(--transition);
    border: 1px solid rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
    width: 100%;
}

.categoria::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
}

.categoria:hover {
    box-shadow: var(--shadow-medium);
    transform: translateY(-3px);
}

.categoria-header {
    position: relative;
}

.categoria-title-wrapper {
    display: flex;
    align-items: center;
    gap: 10px;
}

.categoria-icon {
    color: var(--secondary-color);
    font-size: 20px;
}

.categoria .title {
    font-size: 22px;
    font-weight: 700;
    color: var(--primary-color);
    text-transform: uppercase;
    letter-spacing: 0.8px;
    margin: 0;
}

.produto-count {
    background: linear-gradient(135deg, var(--light-gray), #e9ecef);
    color: var(--dark-gray);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 15px;
    text-transform: lowercase;
}

.categoria .vertudo {
    color: var(--secondary-color);
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
    float: right;
    padding: 8px 15px;
    background: linear-gradient(135deg, rgba(52, 144, 220, 0.1), rgba(41, 128, 185, 0.1));
    border-radius: 20px;
    border: 1px solid rgba(52, 144, 220, 0.2);
}

.categoria .vertudo:hover {
    color: var(--white);
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
    transform: translateX(3px);
    box-shadow: var(--shadow-light);
}

/* ================================================ */
/* MELHORIAS NOS PRODUTOS - LAYOUT TIPO 1 (CARDS) */
/* ================================================ */
.produto {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 15px;
    position: relative;
}

.produto:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-heavy);
}

.produto .capa {
    height: 180px;
    background-size: cover;
    background-position: center;
    position: relative;
    overflow: hidden;
}

.produto .capa::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.4) 100%);
    opacity: 0;
    transition: var(--transition);
}

.produto:hover .capa::after {
    opacity: 1;
}

.produto .nome {
    font-weight: 600;
    color: var(--primary-color);
    font-size: 14px;
    line-height: 1.4;
    padding: 15px 15px 5px;
    display: block;
    text-transform: capitalize;
}

.produto .valor_anterior {
    color: var(--medium-gray);
    font-size: 12px;
    text-decoration: line-through;
    padding: 0 15px;
    display: block;
}

.produto .apenas {
    color: var(--dark-gray);
    font-size: 11px;
    padding: 0 15px;
    display: block;
}

.produto .valor {
    color: var(--success-color);
    font-weight: 700;
    font-size: 16px;
    padding: 0 15px 10px;
    display: block;
}

.produto .detalhes {
    background: linear-gradient(135deg, var(--primary-color), var(--dark-gray));
    color: var(--white);
    padding: 12px;
    text-align: center;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: var(--transition);
}

.produto:hover .detalhes {
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
}

.produto .detalhes.sem-estoque {
    background: linear-gradient(135deg, var(--danger-color), #c0392b);
}

/* ================================================ */
/* MELHORIAS NOS PRODUTOS - LAYOUT TIPO 2 (LISTA) */
/* ================================================ */
.novoproduto {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 15px;
    border: 1px solid rgba(0,0,0,0.05);
}

.novoproduto:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-medium);
    border-color: var(--secondary-color);
}

.novoproduto .nome {
    font-weight: 600;
    color: var(--primary-color);
    font-size: 16px;
    line-height: 1.3;
    margin-bottom: 5px;
    display: block;
}

.novoproduto .descricao {
    color: var(--dark-gray);
    font-size: 13px;
    line-height: 1.4;
    margin-bottom: 8px;
    display: block;
    opacity: 0.8;
}

.novoproduto .preco .valor {
    color: var(--success-color);
    font-weight: 700;
    font-size: 16px;
}

.novoproduto .preco .valor-green {
    color: var(--success-color);
}

.novoproduto .capa {
    border-radius: var(--border-radius);
    overflow: hidden;
    height: 80px;
    position: relative;
}

.novoproduto .capa img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: var(--transition);
}

.novoproduto:hover .capa img {
    transform: scale(1.1);
}

.novoproduto .detalhes {
    background: linear-gradient(135deg, var(--success-color), #2ecc71);
    color: var(--white);
    padding: 8px 15px;
    text-align: center;
    font-weight: 600;
    font-size: 12px;
    margin-top: 10px;
    border-radius: 0 0 var(--border-radius) var(--border-radius);
}

/* ================================================ */
/* SISTEMA DE NOTIFICAÇÕES ALEATÓRIAS */
/* ================================================ */
.notification-toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-heavy);
    z-index: 9999;
    min-width: 300px;
    max-width: 400px;
    opacity: 0;
    transform: translateX(400px);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(0,0,0,0.1);
    overflow: hidden;
}

.notification-toast.show {
    opacity: 1;
    transform: translateX(0);
}

.notification-content {
    display: flex;
    align-items: center;
    padding: 15px;
    gap: 12px;
}

.notification-icon {
    background: linear-gradient(135deg, var(--success-color), #2ecc71);
    color: var(--white);
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}

.notification-text {
    flex: 1;
    line-height: 1.4;
}

.notification-message {
    font-size: 14px;
    color: var(--dark-gray);
    margin-bottom: 2px;
}

.notification-message strong {
    color: var(--primary-color);
    font-weight: 600;
}

.notification-product {
    font-size: 13px;
    color: var(--secondary-color);
    font-weight: 600;
}

.notification-close {
    color: var(--medium-gray);
    cursor: pointer;
    padding: 5px;
    border-radius: 50%;
    transition: var(--transition);
    flex-shrink: 0;
}

.notification-close:hover {
    background: var(--light-gray);
    color: var(--danger-color);
}

.notification-progress {
    height: 3px;
    background: var(--light-gray);
    position: relative;
    overflow: hidden;
}

.notification-progress::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    background: linear-gradient(135deg, var(--secondary-color), #2980b9);
    width: 0%;
    animation: notificationProgress 6s linear;
}

.notification-toast.show .notification-progress::after {
    animation: notificationProgress 6s linear;
}

@keyframes notificationProgress {
    from { width: 0%; }
    to { width: 100%; }
}

/* Responsividade para mobile */
@media (max-width: 768px) {
    .notification-toast {
        top: 10px;
        right: 5px;
        left: 5px;
        min-width: auto;
        max-width: none;
        transform: translateY(-100px);
    }
    
    .notification-toast.show {
        transform: translateY(0);
    }
    
    .notification-content {
        padding: 12px;
    }
    
    .notification-icon {
        width: 35px;
        height: 35px;
        font-size: 16px;
    }
    
    /* REMOÇÃO DE ESPAÇAMENTOS LATERAIS NO MOBILE */
    .sceneElement {
        padding: 0 !important;
        margin: 0 !important;
        width: 100vw !important;
    }
    
    .container, .container-fluid {
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
    }
    
    .row {
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .col-md-12, .col-sm-12, .col-xs-12 {
        padding: 0 !important;
        margin: 0 !important;
    }
    
    /* Busca e categorias mobile */
    .search-bar-mobile {
        margin: 5px 3px !important;
        width: calc(100% - 6px) !important;
    }
    
    /* Banners mobile */
    .banners-container {
        margin: 0 !important;
        padding: 10px 5px !important;
        border-radius: 0 !important;
    }
}

/* ================================================ */
/* MELHORIAS NO POPUP iOS */
/* ================================================ */
#instructionsPopup {
    backdrop-filter: blur(10px);
    background-color: rgba(0,0,0,0.6);
}

#instructionsPopup > div {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-heavy);
    border: 1px solid rgba(0,0,0,0.1);
}

#instructionsPopup h4 {
    color: var(--primary-color);
    font-weight: 700;
}

#instructionsPopup ol {
    color: var(--dark-gray);
}

#closePopupButton {
    color: var(--medium-gray);
    transition: var(--transition);
}

#closePopupButton:hover {
    color: var(--danger-color);
    transform: scale(1.2);
}

/* ================================================ */
/* RESPONSIVIDADE E AJUSTES FINAIS */
/* ================================================ */
@media (max-width: 768px) {
    .categoria {
        margin: 15px;
        padding: 15px;
    }
    
    .sceneElement {
        padding-bottom: 20px;
    }
    
    .info-badges {
        flex-direction: column;
        gap: 10px;
    }
    
    .info-badge {
        min-width: auto;
    }
}

/* ================================================ */
/* MELHORIAS DE RESPONSIVIDADE E EFEITOS FINAIS */
/* ================================================ */

/* Loading skeleton para melhor UX */
.skeleton {
    background: linear-gradient(90deg, var(--light-gray) 25%, #f0f0f0 50%, var(--light-gray) 75%);
    background-size: 200% 100%;
    animation: loading 1.5s infinite;
}

@keyframes loading {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}

/* Melhorias na responsividade */
@media (max-width: 768px) {
    .categoria {
        margin: 0 0 8px 0 !important;
        padding: 15px 8px !important;
        border-radius: 0 !important;
        width: 100% !important;
    }
    
    .categoria-title-wrapper {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
        padding: 5px 0;
    }
    
    .categoria .title {
        font-size: 19px;
        padding: 5px 0;
    }
    
    .categoria-header {
        padding-bottom: 18px !important;
        margin-bottom: 25px !important;
    }
    
    .sceneElement {
        padding: 0 !important;
        background: var(--light-gray);
        width: 100vw !important;
    }
    
    /* Info-badges removidas - não são mais necessárias */
    /*
    .info-badges {
        flex-direction: column;
        gap: 10px;
        margin: 10px 3px !important;
    }
    
    .info-badge {
        min-width: auto;
        padding: 12px;
    }
    */
    
    .status-btn {
        min-width: 180px;
        padding: 12px 20px;
        font-size: 14px;
    }
    
    .banners-container {
        margin: 0 !important;
        padding: 10px 3px !important;
        border-radius: 0 !important;
    }
    
    .carousel-control {
        width: 35px;
        height: 35px;
        font-size: 16px;
    }
}

@media (max-width: 480px) {
    .categoria .vertudo {
        float: none;
        display: block;
        text-align: center;
        margin-top: 10px;
    }
    
    .categoria-header .row {
        flex-direction: column;
    }
    
    .categoria-header .col-md-4 {
        margin-top: 10px;
    }
}

/* Animações suaves para carregamento */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideInRight {
    from {
        opacity: 0;
        transform: translateX(30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.categoria {
    animation: fadeInUp 0.6s ease-out;
}

.produto, .novoproduto {
    animation: fadeInUp 0.4s ease-out;
}

.info-badge {
    animation: slideInRight 0.5s ease-out;
}

.info-badge:nth-child(2) {
    animation-delay: 0.1s;
}

.info-badge:nth-child(3) {
    animation-delay: 0.2s;
}

/* ================================================ */
/* CORREÇÃO DAS CORES DA BARRA SUPERIOR (MINITOP) */
/* ================================================ */

/* Barra superior com cor dinâmica do estabelecimento */
.minitop {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    padding: 12px 0 !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important;
}

/* Info badges da barra superior com texto branco */
.info-badges-desktop .info-badge {
    background: rgba(255,255,255,0.15) !important;
    color: var(--white) !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    padding: 6px 12px !important;
    margin-right: 12px !important;
    transition: var(--transition) !important;
    backdrop-filter: blur(10px) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
}

.info-badges-desktop .info-badge:hover {
    background: rgba(255,255,255,0.25) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2) !important;
}

.info-badges-desktop .info-badge i {
    color: var(--white) !important;
    margin-right: 6px !important;
    font-weight: bold !important;
    opacity: 0.9 !important;
}

.info-badges-desktop .info-badge span {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

/* Status de funcionamento */
.funcionamento {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.funcionamento .aberto {
    color: #4CAF50 !important;
    background: rgba(76,175,80,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(76,175,80,0.3) !important;
}

.funcionamento .fechado {
    color: #f44336 !important;
    background: rgba(244,67,54,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(244,67,54,0.3) !important;
}

.funcionamento i {
    margin-right: 6px !important;
    font-weight: bold !important;
}

/* ================================================ */
/* ESTILO PARA PEDIDO MÍNIMO E WHATSAPP - ÍCONES NA LATERAL */
/* ================================================ */
.app-infos-labels {
    background: linear-gradient(135deg, var(--light-gray), #e9ecef);
    border-radius: 8px;
    padding: 12px 15px;
    margin: 8px 0;
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    border: 1px solid rgba(0,0,0,0.05);
}

.app-infos-labels:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-medium);
    background: linear-gradient(135deg, #e8f4f8, #d4e6f1);
}

.app-infos-labels i {
    color: var(--primary-color);
    font-size: 16px;
    margin-right: 8px;
    display: inline-block;
    vertical-align: middle;
}

.app-infos-labels span {
    color: var(--dark-gray);
    font-weight: 600;
    font-size: 13px;
    display: inline-block;
    vertical-align: middle;
}

.app-infos-labels a {
    color: var(--dark-gray);
    text-decoration: none;
    transition: var(--transition);
}

.app-infos-labels a:hover {
    color: var(--primary-color);
}

/* ================================================ */
/* PRODUTOS EM CARROSSEL - 4 DESKTOP, 2 MOBILE */
/* ================================================ */
.tv-infinite {
    display: flex;
    overflow-x: auto;
    gap: 15px;
    padding: 15px 0;
    scroll-behavior: smooth;
    scrollbar-width: thin;
    scrollbar-color: var(--medium-gray) transparent;
    /* Melhoria da navegação por toque */
    -webkit-overflow-scrolling: touch;
    position: relative;
}

.tv-infinite::-webkit-scrollbar {
    height: 8px;
}

.tv-infinite::-webkit-scrollbar-track {
    background: var(--light-gray);
    border-radius: 4px;
}

.tv-infinite::-webkit-scrollbar-thumb {
    background: var(--medium-gray);
    border-radius: 4px;
    transition: var(--transition);
}

.tv-infinite::-webkit-scrollbar-thumb:hover {
    background: var(--secondary-color);
}

/* Indicador de mais conteúdo à direita - REMOVIDO */
/* 
.tv-infinite::after {
    content: '→';
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    background: linear-gradient(90deg, transparent, var(--white) 30%);
    color: var(--secondary-color);
    font-size: 24px;
    font-weight: bold;
    padding: 10px;
    pointer-events: none;
    opacity: 0.7;
    z-index: 2;
}
*/

.col-infinite {
    flex: 0 0 auto;
    width: calc(25% - 11.25px); /* 4 por linha no desktop */
    min-width: 200px;
    /* Garantir que os cards não encolham */
    flex-shrink: 0;
}

.novalistagem {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 15px;
    padding: 10px 0;
}

.novalistagem .col-md-6 {
    width: 100%;
}

/* Melhorias visuais nos produtos TIPO 1 (Cards) */
.produto {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 0;
    position: relative;
    border: 1px solid rgba(0,0,0,0.05);
    cursor: pointer;
}

.produto:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-heavy);
    border-color: var(--primary-color);
}

.produto .capa {
    height: 180px;
    background-size: cover;
    background-position: center;
    position: relative;
    overflow: hidden;
}

.produto .capa::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(0,0,0,0.1), transparent);
    opacity: 0;
    transition: var(--transition);
}

.produto:hover .capa::before {
    opacity: 1;
}

.produto .nome {
    font-weight: 600;
    color: var(--primary-color);
    font-size: 14px;
    line-height: 1.4;
    padding: 15px 15px 5px;
    display: block;
    text-transform: capitalize;
}

.produto .valor_anterior {
    color: var(--medium-gray);
    font-size: 12px;
    text-decoration: line-through;
    padding: 0 15px;
    display: block;
}

.produto .apenas {
    color: var(--dark-gray);
    font-size: 11px;
    padding: 0 15px;
    display: block;
}

.produto .valor {
    color: var(--success-color);
    font-weight: 700;
    font-size: 16px;
    padding: 0 15px 10px;
    display: block;
}

.produto .detalhes {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    padding: 12px;
    text-align: center;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: var(--transition);
}

.produto:hover .detalhes {
    background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
}

.produto .detalhes.sem-estoque {
    background: linear-gradient(135deg, var(--danger-color), #c0392b);
}

/* Melhorias no layout TIPO 2 (Lista) */
.novoproduto {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-light);
    transition: var(--transition);
    overflow: hidden;
    margin-bottom: 0;
    border: 1px solid rgba(0,0,0,0.05);
    padding: 15px;
    cursor: pointer;
}

.novoproduto:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-medium);
    border-color: var(--primary-color);
}

.novoproduto .capa {
    border-radius: 8px;
    overflow: hidden;
    height: 90px;
    position: relative;
}

.novoproduto .capa img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: var(--transition);
}

.novoproduto:hover .capa img {
    transform: scale(1.05);
}

.novoproduto .nome {
    font-weight: 600;
    color: var(--primary-color);
    font-size: 15px;
    line-height: 1.3;
    margin-bottom: 6px;
    display: block;
}

.novoproduto .descricao {
    color: var(--dark-gray);
    font-size: 12px;
    line-height: 1.4;
    margin-bottom: 10px;
    display: block;
    opacity: 0.8;
}

.novoproduto .preco .valor {
    color: var(--success-color);
    font-weight: 700;
    font-size: 16px;
}

.novoproduto .detalhes {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    padding: 8px 15px;
    text-align: center;
    font-weight: 600;
    font-size: 12px;
    margin-top: 10px;
    border-radius: 0 0 var(--border-radius) var(--border-radius);
    transition: var(--transition);
}

.novoproduto:hover .detalhes {
    background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
}

/* Responsividade da grade */
@media (max-width: 768px) {
    .tv-infinite {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 10px;
        padding: 10px 0;
    }
    
    .novalistagem {
        grid-template-columns: 1fr;
        gap: 10px;
    }
    
    .produto .capa {
        height: 140px;
    }
    
    .novoproduto .capa {
        height: 70px;
    }
}

@media (max-width: 480px) {
    .tv-infinite {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
    }
    
    .produto .capa {
        height: 120px;
    }
    
    .produto .nome {
        font-size: 13px;
        padding: 10px 10px 5px;
    }
    
    .produto .valor {
        font-size: 14px;
        padding: 0 10px 8px;
    }
    
    .produto .detalhes {
        padding: 10px;
        font-size: 12px;
    }
}

/* Melhorias no container principal */
.middle.minfit {
    background: transparent;
    padding-top: 20px;
}

.container {
    max-width: 1200px;
}

/* Efeito de focus melhorado para acessibilidade */
*:focus {
    outline: 2px solid var(--secondary-color);
    outline-offset: 2px;
    border-radius: 4px;
}

/* Print styles */
@media print {
    .carousel-control,
    .install-buttons,
    .search-bar-mobile {
        display: none !important;
    }
    
    .categoria {
        box-shadow: none;
        border: 1px solid #ddd;
    }
}

@media (max-width: 768px) {
    .col-infinite {
        width: calc(50% - 7.5px); /* 2 por linha no celular */
        min-width: 150px;
    }
    
    .tv-infinite {
        gap: 8px;
        padding: 15px 3px !important;
        margin: 0 !important;
        width: 100% !important;
    }
    
    /* CATEGORIAS EM CARROSSEL NO CELULAR */
    .tv-infinite-menu {
        display: flex;
        overflow-x: auto;
        gap: 8px;
        padding: 10px 3px !important;
        scroll-behavior: smooth;
        scrollbar-width: none;
        -ms-overflow-style: none;
        -webkit-overflow-scrolling: touch;
        margin: 0 !important;
        width: 100% !important;
    }
    
    .tv-infinite-menu::-webkit-scrollbar {
        display: none;
    }
    
    .tv-infinite-menu a {
        flex: 0 0 auto;
        min-width: 80px;
        text-align: center;
        white-space: nowrap;
        padding: 8px 12px;
        background: var(--light-gray);
        color: var(--dark-gray);
        text-decoration: none;
        border-radius: 6px;
        transition: var(--transition);
        font-size: 0.85rem;
        border: 1px solid transparent;
    }
    
    .tv-infinite-menu a.active,
    .tv-infinite-menu a:hover {
        background: var(--secondary-color);
        color: white;
        border-color: var(--secondary-color);
    }
    
    .cats {
        display: flex;
        overflow-x: auto;
        gap: 10px;
        padding: 10px 0;
        scroll-behavior: smooth;
        scrollbar-width: none;
        -ms-overflow-style: none;
    }
    
    .cats::-webkit-scrollbar {
        display: none;
    }
    
    .cats .link_cat {
        flex: 0 0 auto;
        min-width: 120px;
        text-align: center;
        white-space: nowrap;
    }
    
    .cats .link_cat .nome {
        font-size: 0.85rem;
        padding: 5px 8px;
    }
}

/* Tema escuro (preparação futura) */
@media (prefers-color-scheme: dark) {
    :root {
        --primary-color: #ecf0f1;
        --secondary-color: #3498db;
        --light-gray: #2c3e50;
        --white: #34495e;
        --dark-gray: #ecf0f1;
    }
}

/* ================================================ */
/* FORÇAR CORES DA BARRA SUPERIOR EM TODOS OS DISPOSITIVOS */
/* ================================================ */

/* Garantir que a barra superior sempre tenha as cores corretas */
.header .minitop {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
}

.header .minitop .info-badges-desktop .info-badge {
    background: rgba(255,255,255,0.15) !important;
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .info-badges-desktop .info-badge i {
    color: var(--white) !important;
    opacity: 0.9 !important;
}

.header .minitop .info-badges-desktop .info-badge span {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .funcionamento {
    color: var(--white) !important;
    font-weight: 600 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
}

.header .minitop .funcionamento .aberto,
.header .minitop .funcionamento .fechado {
    color: inherit !important;
    background: rgba(255,255,255,0.1) !important;
    padding: 4px 8px !important;
    border-radius: 4px !important;
    border: 1px solid rgba(255,255,255,0.2) !important;
}

/* Mobile - garantir que mesmo no mobile as cores sejam consistentes */
@media (max-width: 768px) {
    .header .minitop {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    }
    
    .header .minitop .info-badges-desktop .info-badge {
        color: var(--white) !important;
        background: rgba(255,255,255,0.15) !important;
        font-weight: 600 !important;
        text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
    }
    
    .header .minitop .funcionamento {
        color: var(--white) !important;
        font-weight: 600 !important;
        text-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
    }
}
</style>

<div class="sceneElement">
    <!-- ************************************************ -->
    <!-- CABEÇALHO MOBILE COM INFORMAÇÕES DO ESTABELECIMENTO -->
    <!-- ************************************************ -->
    <div class="container nopadd visible-xs visible-sm">
        <!-- Imagem de capa do estabelecimento -->
        <!-- Adicionado background-size: cover; e restaurado o IMG condicional -->
        <div class="cover" style="background: url('<?php echo $app['cover']; ?>') no-repeat top center; background-size: cover;">
            <?php if(data_info("estabelecimentos", $app['id'], "capa")) { ?>
                <img src="<?php echo $app['cover']; ?>" style="width: 100%; height: auto; display: block;"/>
            <?php } ?>
        </div>

        <!-- Avatar do estabelecimento -->
        <div class="grudado">
            <div class="avatar">
                <div class="holder">
                    <a href="<?php echo $app['url']; ?>">
                        <img src="<?php echo $app['avatar']; ?>" alt="<?php echo $app['title']; ?>" title="<?php echo $app['title']; ?>"/>
                    </a>
                </div>    
            </div>
        </div>
        
        <!-- Informações do estabelecimento -->
        <div class="app-infos">
            <!-- Nome do estabelecimento -->
            <div class="row">
                <div class="col-md-12">
                    <span class="title"><?php echo $app['title']; ?></span>
                </div>
            </div>
            
            <!-- Descrição do estabelecimento -->
            <div class="row">
                <div class="col-md-12">
                    <span class="description"><?php echo $app['description']; ?></span>
                </div>
            </div>
            
            <!-- Status de funcionamento (aberto/fechado) -->
            <div class="row">
                <div class="col-md-12">
                    <div class="status-container" style="text-align: center; margin: 15px 0;">
                        <?php if(verifica_horario($app['id']) == "disabled") { ?>
                            <?php if(data_info("estabelecimentos", $app['id'], "funcionamento") == "1") { ?>
                                <button class="btn btn-success btn-lg status-btn">
                                    <i class="lni lni-checkmark-circle"></i> 
                                    <span>Aberto para Pedidos</span>
                                </button>
                            <?php } else { ?>
                                <button class="btn btn-danger btn-lg status-btn">
                                    <i class="lni lni-cross-circle"></i> 
                                    <span>Fechado para Pedidos</span>
                                </button>
                            <?php } ?>
                        <?php } else if(verifica_horario($app['id']) == "open") { ?>
                                <button class="btn btn-success btn-lg status-btn">
                                    <i class="lni lni-checkmark-circle"></i> 
                                    <span>Aberto para Pedidos</span>
                                </button>
                        <?php } else if(verifica_horario($app['id']) == "close") { ?>
                                <button class="btn btn-danger btn-lg status-btn">
                                    <i class="lni lni-cross-circle"></i> 
                                    <span>Fechado para Pedidos</span>
                                </button>
                        <?php } ?>
                    </div>
                </div>
            </div>
            
            <!-- Informações adicionais (pedido mínimo e compartilhamento) -->
            <div class="row">
                <div class="col-md-12">
                    <?php if($app['pedido_minimo']) { ?>
                    <div class="app-infos-labels">
                        <span><i class="lni lni-money-protection"></i> Pedido minímo: <?php echo $app['pedido_minimo']; ?></span>
                        <div class="clear"></div>
                    </div>
                    <?php } ?>
                    
                    <div class="app-infos-labels">
                        <span><i class="lni lni-whatsapp"></i> <a href="https://api.whatsapp.com/send?text=*Abre%20ai*%20e%20confere%20essa%20novidade.%20%20<?php print $pegaurlx; ?>" target="_blank">
                            Compartilhe no WhatsAPP
                        </a></span>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>    

            <!-- Botões de Instalação PWA (Mobile) -->
            <div class="row visible-xs visible-sm">
                <div class="col-xs-12">
                    <!-- Removido text-align: center; Adicionado flex para alinhar lado a lado -->
                    <div class="install-buttons" style="display: flex; justify-content: center; align-items: center; margin-top: 10px; margin-bottom: 15px;">
                        <button id="installButton" class="btn btn-primary btn-sm" style="margin-right: 5px; display: none;">Instalar App (Android)</button>
                        <button id="showInstructionsButton" class="btn btn-info btn-sm" style="display: none;">Instalar App (iOS)</button>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Popup de Instruções iOS -->
    <div id="instructionsPopup" style="display: none; position: fixed; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); z-index: 1050; padding: 20px; box-sizing: border-box; align-items: center; justify-content: center;">
        <div style="background-color: white; padding: 25px; border-radius: 8px; max-width: 450px; margin: 20px auto; position: relative; text-align: left; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <button id="closePopupButton" style="position: absolute; top: 10px; right: 15px; background: none; border: none; font-size: 2em; color: #888; line-height: 1;">&times;</button>
            <h4 style="margin-top: 0; margin-bottom: 15px; font-size: 1.3em; color: #333;">Instruções para iOS</h4>
            <p style="margin-bottom: 15px; color: #555;">Para adicionar este app à sua Tela de Início:</p>
            <ol style="padding-left: 20px; margin-bottom: 0; color: #555;">
                <li style="margin-bottom: 10px;">Toque no botão de <strong>Compartilhar</strong> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-up" viewBox="0 0 16 16" style="vertical-align: -2px;"><path fill-rule="evenodd" d="M3.5 6a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 1 0-1h2A1.5 1.5 0 0 1 14 6.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 14.5v-8A1.5 1.5 0 0 1 3.5 5h2a.5.5 0 0 1 0 1h-2z"/><path fill-rule="evenodd" d="M7.646.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 1.707V10.5a.5.5 0 0 1-1 0V1.707L5.354 3.854a.5.5 0 1 1-.708-.708l3-3z"/></svg> (na barra inferior do Safari).</li>
                <li style="margin-bottom: 10px;">Role para baixo e toque em "<strong>Adicionar à Tela de Início</strong>".</li>
                <li>Confirme tocando em "<strong>Adicionar</strong>" no canto superior direito.</li>
            </ol>
        </div>
    </div>
    <!-- Fim Popup -->

    <!-- ************************************************ -->
    <!-- SISTEMA DE NOTIFICAÇÕES ALEATÓRIAS -->
    <!-- ************************************************ -->
    <div id="notificationToast" class="notification-toast">
        <div class="notification-content">
            <div class="notification-icon">
                <i class="lni lni-checkmark-circle"></i>
            </div>
            <div class="notification-text">
                <div class="notification-message">
                    <strong id="customerName">João</strong> acabou de comprar
                </div>
                <div class="notification-product" id="productName">
                    Hambúrguer Especial
                </div>
            </div>
            <div class="notification-close" onclick="hideNotification()">
                <i class="lni lni-close"></i>
            </div>
        </div>
        <div class="notification-progress"></div>
    </div>

    <!-- ************************************************ -->
    <!-- CONTEÚDO PRINCIPAL DA PÁGINA -->
    <!-- ************************************************ -->
    <div class="middle minfit">
        <div class="container">
            <!-- Linha divisória para mobile -->
            <div class="row visible-xs visible-sm">
                <div class="col-md-12">
                    <div class="clearline"></div>
                </div>
            </div>
            
            <!-- ************************************************ -->
            <!-- BARRA DE BUSCA E NAVEGAÇÃO MOBILE -->
            <!-- ************************************************ -->
            <div class="row">
                <!-- Campo de busca mobile -->
                <div class="col-md-12">
                    <div class="search-bar-mobile visible-xs visible-sm">
                        <form class="align-middle" action="<?php echo $app['url']; ?>/categoria" method="GET">
                            <input type="text" name="busca" placeholder="Digite sua busca..." value="<?php echo htmlclean($_GET['busca']); ?>"/>
                            <input type="hidden" name="categoria" value="<?php echo $categoria; ?>"/>
                            <button>
                                <i class="lni lni-search-alt"></i>
                            </button>
                            <div class="clear"></div>
                        </form>
                    </div>
                </div>
                
                <!-- Menu de categorias mobile -->
                <div class="col-md-12">
                    <div class="search-bar-mobile visible-xs visible-sm">
                        <div class="tv-infinite tv-infinite-menu">
                            <a class="<?php if(!$categoria){ echo 'active'; }; ?>" href="<?php echo $app['url']; ?>/categoria?<?php echo $query_busca; ?>">Todas</a>
                            <?php        
                            $query_categorias = mysqli_query($db_con, "SELECT * FROM categorias WHERE rel_estabelecimentos_id = '$app_id' AND visible = '1' AND status = '1' ORDER BY ordem ASC");
                            while($data_categoria = mysqli_fetch_array($query_categorias)) {
                            ?>
                            <a class="<?php if($data_categoria['id'] == $categoria){ echo 'active'; }; ?>" href="<?php echo $app['url']; ?>/categoria/<?php echo $data_categoria['id']; ?><?php if($query_busca) { echo "?".$query_busca; }; ?>"><?php echo $data_categoria['nome']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ************************************************ -->
            <!-- SEÇÃO DE BANNERS PROMOCIONAIS (QUANDO ATIVADO) -->
            <!-- ************************************************ -->
            <?php if($app['funcionalidade_banners']) { ?>
                <?php
                $eid = $app['id'];
                $query_banners = mysqli_query($db_con, "SELECT * FROM banners WHERE rel_estabelecimentos_id = '$eid' AND status = '1' ORDER BY id DESC LIMIT 8");
                $has_banners = mysqli_num_rows($query_banners);
                if($has_banners && $app['funcionalidade_banners'] == 1) {
                ?>
                <div class="banners">
                    <div class="banners-container">
                        <div class="banners-header">
                            <h3 class="banners-title">
                                <i class="lni lni-star-filled"></i>
                                Ofertas Especiais
                            </h3>
                        </div>
                        <div id="carouselbanners" class="carousel slide" data-ride="carousel" data-interval="5000">
                            <!-- Indicadores -->
                            <?php if($has_banners >= 2) { ?>
                            <ol class="carousel-indicators">
                                <?php for($i = 0; $i < $actual; $i++) { ?>
                                <li data-target="#carouselbanners" data-slide-to="<?php echo $i; ?>" <?php if($i == 0) echo 'class="active"'; ?>></li>
                                <?php } ?>
                            </ol>
                            <?php } ?>
                            
                            <div class="carousel-inner">
                                <?php
                                $actual = 0;
                                mysqli_data_seek($query_banners, 0); // Reset pointer
                                while($data_banners = mysqli_fetch_array($query_banners)) {
                                $banner_video_link = $data_banners['video_link'];
                                $desktop = $data_banners['desktop'];
                                $mobile = $data_banners['mobile'];
                                if(!$mobile) {
                                    $mobile = $desktop;
                                }
                                ?>
                                <div class="item <?php if($actual == 0) { echo 'active'; }; ?>">
                                    <?php if($data_banners['link']) { ?>
                                    <a href="<?php echo linker($data_banners['link']); ?>" class="banner-link">
                                    <?php } ?>
                                        <img class="hidden-xs hidden-sm" src="<?php echo imager($desktop); ?>" alt="Banner promocional"/>
                                        <?php
                                            // Se tiver o link do vídeo para o banner, será renderizado o vídeo, do contrário, será renderizado a imagem
                                            if($banner_video_link) {
                                        ?>
                                            <iframe class="visible-xs visible-sm" width="100%" height="240px" src="https://www.youtube.com/embed/<?php echo $banner_video_link; ?>" frameborder="0" allowfullscreen>
                                            </iframe>
                                        <?php
                                            } else {
                                        ?>
                                            <img class="visible-xs visible-sm" src="<?php echo imager($mobile); ?>" alt="Banner promocional"/>
                                        <?php
                                            };
                                        ?>
                                    <?php if($data_banners['link']) { ?>
                                    </a>
                                    <?php } ?>
                                </div>
                                <?php $actual++; } ?>
                            </div>
                            
                            <!-- Controles do carrossel (apenas se tiver mais de um banner) -->
                            <?php if($has_banners >= 1 && $actual >= 2) { ?>
                                <a class="left carousel-control" href="#carouselbanners" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left"></span>
                                    <span class="sr-only">Anterior</span>
                                </a>
                                <a class="right carousel-control" href="#carouselbanners" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right"></span>
                                    <span class="sr-only">Próximo</span>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php } ?>
            <?php } ?>

            <!-- ************************************************ -->
            <!-- LISTAGEM DE CATEGORIAS E PRODUTOS -->
            <!-- ************************************************ -->
            <div class="categorias">
                <?php
                $app_id = $app['id'];
                // Consulta que agrupa produtos por categoria, contando quantos produtos existem em cada
                $query_categoria = 
                "
                SELECT *, count(*) as total, categorias.nome as categoria_nome, categorias.id as categoria_id, count(produtos.id) as produtos_total
                FROM categorias AS categorias 
                INNER JOIN produtos AS produtos 
                ON produtos.rel_categorias_id = categorias.id 
                WHERE categorias.rel_estabelecimentos_id = '$app_id' 
                AND categorias.visible = '1' 
                AND categorias.status = '1' 
                GROUP BY categorias.id 
                ORDER BY categorias.ordem ASC
                LIMIT 20
                ";
                $query_categoria = mysqli_query($db_con, $query_categoria);
                while($data_categoria = mysqli_fetch_array($query_categoria)) {
                ?>
                <!-- Reduzido margin-bottom para diminuir espaço entre categorias -->
                <div class="categoria" style="margin-bottom: 25px;">
                    <!-- Cabeçalho da categoria com título e link "ver tudo" -->
                    <div class="categoria-header" style="border-bottom: 2px solid #f8f9fa; padding-bottom: 15px; margin-bottom: 20px;">
                        <div class="row">
                            <div class="col-md-8 col-sm-8 col-xs-8">
                                <div class="categoria-title-wrapper">
                                    <i class="lni lni-grid-alt categoria-icon"></i>
                                    <span class="title"><?php echo htmlclean($data_categoria['categoria_nome']); ?></span>
                                    <span class="produto-count">(<?php echo $data_categoria['produtos_total']; ?> produtos)</span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                <a class="vertudo" href="<?php echo $app['url']; ?>/categoria/<?php echo $data_categoria['categoria_id']; ?>">
                                    Ver tudo <i class="lni lni-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Listagem de produtos da categoria -->
                    <div class="produtos">
                        <div class="row">
                            <!-- Definição do tipo de exibição com base na configuração do app -->
                            <?php if($app['exibicao'] == 1){ ?>
                            <!-- Ajuste de padding/margin para mobile no container tv-infinite -->
                            <div class="tv-infinite" style="margin: 0; padding: 10px 5px; width: 100%;"> 
                            <?php } ?>
                            
                            <?php if($app['exibicao'] == 2){ ?>
                            <div class="novalistagem">
                            <?php } ?>
                                
                                <?php
                                // Detecção de dispositivo móvel (mantida para referência, mas não usada para LIMIT)
                                $userAgent = $_SERVER['HTTP_USER_AGENT'];
                                $isMobile = preg_match('/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i', $userAgent);
                                
                                // Consulta dos produtos da categoria atual - SEM LIMIT
                                $cat_id = $data_categoria['categoria_id'];
                                $query_produtos = mysqli_query($db_con, "SELECT * FROM produtos WHERE rel_categorias_id = '$cat_id' AND visible = '1' AND status = '1' ORDER BY id ASC"); // SEM LIMIT
                                while($data_produtos = mysqli_fetch_array($query_produtos)) {
                                    // Definição do valor final (normal ou promocional)
                                    if($data_produtos['oferta'] == "1") {
                                        $valor_final = $data_produtos['valor_promocional'];
                                    } else {
                                        $valor_final = $data_produtos['valor'];
                                    }
                                ?>
                                
                                <!-- EXIBIÇÃO TIPO 2: Layout com imagem à direita e texto à esquerda -->
                                <?php if($app['exibicao'] == 2){ ?>
                                    <!-- Adicionado col-xs-12 para garantir que ocupe a largura total em mobile -->
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <div class="novoproduto">
                                            <a href="<?php echo $app['url']; ?>/produto/<?php echo $data_produtos['id']; ?>" title="<?php echo $data_produtos['nome']; ?>">
                                                <div class="row">
                                                    <!-- Informações do produto (nome, descrição, preço) -->
                                                    <div class="col-md-9 col-sm-7 col-xs-7 npr">
                                                        <span class="nome"><?php echo htmlclean($data_produtos['nome']); ?></span>
                                                        <span class="descricao"><?php echo htmlclean($data_produtos['descricao']); ?></span>
                                                        <div class="preco">
                                                            <?php if($valor_final > 0) { ?>
                                                                <?php if($data_produtos['oferta'] == "1") { ?>
                                                                    <span class="valor valor-green">Por R$ <?php echo dinheiro($valor_final, "BR"); ?></span>
                                                                <?php } else { ?>
                                                                    <span class="valor valor-green">R$: <?php echo dinheiro($valor_final, "BR"); ?></span>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <!-- Produto com preço variável ou opcionais -->
                                                                <span class="valor ">VER OPÇÕES</span>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <!-- Imagem do produto -->
                                                    <div class="col-md-3 col-sm-5 col-xs-5">
                                                        <div class="capa">
                                                            <img src="<?php echo thumber($data_produtos['destaque'], 450); ?>"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- Botão de compra ou aviso de sem estoque -->
                                                <?php if($data_produtos['estoque'] == 1 || ($data_produtos['estoque'] == 2 && $data_produtos['posicao'] > 0)) { ?>
                                                    <div class="detalhes"><i class="icone icone-sacola"></i> <span>Comprar</span></div>
                                                <?php } else { ?>
                                                    <div style="padding:5px; color:#333; font-size:12px;"><i class="lni lni-close" style="color:#FF0000; font-weight:bold;"></i> <span>Sem Estoque</span></div>
                                                <?php } ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php } ?>
                                
                                <!-- EXIBIÇÃO TIPO 1: Layout de cards com imagem em destaque -->
                                <?php if($app['exibicao'] ==  1){ ?>
                                    <!-- REMOVIDO col-md-3 col-sm-4 col-xs-6 -->
                                    <div class="col-infinite" style="padding-left: 5px; padding-right: 5px;">
                                        <div class="produto">
                                            <a href="<?php echo $app['url']; ?>/produto/<?php echo $data_produtos['id']; ?>" title="<?php echo $data_produtos['nome']; ?>">
                                                <div class="capa" style="background-image: url(<?php echo thumber($data_produtos['destaque'], 450); ?>);"></div>
                                                <span class="nome"><?php echo htmlclean($data_produtos['nome']); ?></span>
                                                
                                                <?php if($valor_final > 0) { ?>
                                                    <?php if($data_produtos['oferta'] == "1") { ?>
                                                        <span class="valor_anterior">De: <?php echo dinheiro($data_produtos['valor'], "BR"); ?></span>
                                                    <?php } else { ?>
                                                        <span class="valor_anterior invisible">&nbsp;</span>
                                                    <?php } ?>
                                                    <span class="apenas">Por apenas</span>
                                                    <span class="valor">R$ <?php echo dinheiro($valor_final, "BR"); ?></span>
                                                    
                                                    <!-- Verificação de estoque -->
                                                    <?php if($data_produtos['estoque'] == 1 || ($data_produtos['estoque'] == 2 && $data_produtos['posicao'] > 0)) { ?>
                                                        <div class="detalhes"><i class="icone icone-sacola"></i> <span>Comprar</span></div>
                                                    <?php } else { ?>
                                                        <div class="detalhes sem-estoque"><i class="lni lni-close"></i> <span>Sem Estoque</span></div>
                                                    <?php } ?>
                                                <?php } else { ?>
                                                    <!-- Produto com preço variável/opcionais -->
                                                    <span class="apenas">Este item possui</span>
                                                    <span class="apenas">opcionais</span>
                                                    <span class="valor" style="color:#FFFFFF">.</span>
                                                    <div class="detalhes"><i class="icone icone-sacola"></i> <span>Selecione</span></div>
                                                <?php } ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php } ?>
                                <?php } ?>
                                
                                <!-- Botão "Ver tudo" adicional apenas para mobile - MANTIDO REMOVIDO -->
                                <?php /* if($app['exibicao'] == 1){ ?>
                                <div class="col-md-3 col-sm-4 col-xs-6 col-infinite col-infinite-last visible-xs visible-sm" style="padding-left: 5px; padding-right: 5px;">
                                    <a class="vertudo" href="<?php echo $app['url']; ?>/categoria/<?php echo $data_categoria['categoria_id']; ?>">Ver tudo <i class="lni lni-arrow-right"></i></a>
                                </div>
                                <?php } */ ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php 
// ************************************************
// CARREGAMENTO DO RODAPÉ
// ************************************************
$system_footer .= "";
?>

<script>
// ************************************************
// LÓGICA PWA E SISTEMA DE NOTIFICAÇÕES
// ************************************************
document.addEventListener('DOMContentLoaded', (event) => {
    const installButton = document.getElementById('installButton');
    const showInstructionsButton = document.getElementById('showInstructionsButton');
    const instructionsPopup = document.getElementById('instructionsPopup');
    const closePopupButton = document.getElementById('closePopupButton');
    let deferredPrompt; // Variável para guardar o evento beforeinstallprompt

    // --- Lógica PWA ---
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        console.log('`beforeinstallprompt` event fired.');
        // Se o prompt está disponível, potencialmente mostramos o botão Android
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
        if (!isStandalone && installButton) {
             // Apenas marca que o prompt está pronto, a exibição é tratada abaixo
        }
    });

    if (installButton) {
         installButton.addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                console.log(`User response to the install prompt: ${outcome}`);
                deferredPrompt = null;
                installButton.style.display = 'none'; // Esconde após tentativa
            } else {
                 console.log('O prompt de instalação PWA não está disponível.');
                 // Poderia adicionar uma mensagem para o usuário aqui
            }
        });
    }

     window.addEventListener('appinstalled', () => {
        if (installButton) {
            installButton.style.display = 'none';
        }
        if (showInstructionsButton) {
             showInstructionsButton.style.display = 'none'; // Esconde botão iOS também se instalar
        }
        deferredPrompt = null;
        console.log('PWA foi instalado');
    });

    // --- Lógica de Exibição dos Botões ---
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;

    if (isStandalone) {
        console.log('Rodando como PWA standalone.');
        // Esconde ambos os botões se já estiver instalado/standalone
         if (installButton) installButton.style.display = 'none';
         if (showInstructionsButton) showInstructionsButton.style.display = 'none';
    } else {
         console.log('Rodando no navegador.');
         // Se não for standalone, mostra ambos os botões
         // O botão Android só funcionará se deferredPrompt estiver disponível
         if (installButton) {
             installButton.style.display = 'inline-block';
         }
         if (showInstructionsButton) {
             showInstructionsButton.style.display = 'inline-block';
         }
         // Opcional: Poderíamos desabilitar o botão Android se deferredPrompt for null
         // if (installButton && !deferredPrompt) {
         //     installButton.disabled = true;
         //     installButton.title = "Instalação não disponível neste navegador";
         // }
    }

    // --- Lógica Popup iOS ---
    if (showInstructionsButton && instructionsPopup) {
        showInstructionsButton.addEventListener('click', () => {
            instructionsPopup.style.display = 'flex'; // Usar flex para centralizar
        });
    }

    if (closePopupButton && instructionsPopup) {
        closePopupButton.addEventListener('click', () => {
            instructionsPopup.style.display = 'none';
        });
    }

    // Fechar popup clicando fora da caixa de diálogo
    if (instructionsPopup) {
        instructionsPopup.addEventListener('click', (e) => {
            // Verifica se o clique foi no fundo (o próprio popup) e não nos seus filhos
            if (e.target === instructionsPopup) { 
                instructionsPopup.style.display = 'none';
            }
        });
    }

    // ================================================================
    // SISTEMA DE NOTIFICAÇÕES ALEATÓRIAS COM PRODUTOS REAIS
    // ================================================================
    
    // Nomes fictícios para as notificações
    const randomNames = [
        'Ana', 'Carlos', 'Maria', 'João', 'Fernanda', 'Pedro', 'Juliana', 'Roberto',
        'Camila', 'Bruno', 'Larissa', 'Diego', 'Patrícia', 'Lucas', 'Renata', 'Gabriel',
        'Mariana', 'Rafael', 'Beatriz', 'Thiago', 'Amanda', 'Felipe', 'Carla', 'Rodrigo',
        'Vanessa', 'Marcos', 'Priscila', 'André', 'Carolina', 'Gustavo', 'Isabela', 'Daniel',
        'Michelle', 'Leonardo', 'Natália', 'Vinícius', 'Tatiana', 'Leandro', 'Sandra', 'Fábio'
    ];

    // Produtos reais da loja (obtidos do PHP)
    const storeProducts = [
        <?php
        $app_id = $app['id'];
        $query_all_products = mysqli_query($db_con, "SELECT nome FROM produtos WHERE rel_categorias_id IN (SELECT id FROM categorias WHERE rel_estabelecimentos_id = '$app_id') AND visible = '1' AND status = '1' ORDER BY RAND() LIMIT 20");
        $products_js = [];
        while($product_data = mysqli_fetch_array($query_all_products)) {
            $products_js[] = "'" . addslashes($product_data['nome']) . "'";
        }
        echo implode(', ', $products_js);
        ?>
    ];

    let notificationTimeout;
    let notificationInterval;

    function getRandomName() {
        return randomNames[Math.floor(Math.random() * randomNames.length)];
    }

    function getRandomProduct() {
        if (storeProducts.length === 0) {
            return 'Produto Especial';
        }
        return storeProducts[Math.floor(Math.random() * storeProducts.length)];
    }

    function showRandomNotification() {
        const toast = document.getElementById('notificationToast');
        const customerNameElement = document.getElementById('customerName');
        const productNameElement = document.getElementById('productName');
        
        // Atualizar o conteúdo da notificação
        customerNameElement.textContent = getRandomName();
        productNameElement.textContent = getRandomProduct();
        
        // Mostrar a notificação
        toast.classList.add('show');
        
        // Esconder automaticamente após 6 segundos
        notificationTimeout = setTimeout(() => {
            hideNotification();
        }, 6000);
    }

    function hideNotification() {
        const toast = document.getElementById('notificationToast');
        toast.classList.remove('show');
        
        if (notificationTimeout) {
            clearTimeout(notificationTimeout);
        }
    }

    // Função global para o botão de fechar
    window.hideNotification = hideNotification;

    // Iniciar o sistema de notificações
    function startNotificationSystem() {
        // Primeira notificação após 5 segundos
        setTimeout(() => {
            showRandomNotification();
        }, 5000);
        
        // Notificações subsequentes a cada 20-40 segundos
        notificationInterval = setInterval(() => {
            // 25% de chance de mostrar uma notificação
            if (Math.random() < 0.25) {
                showRandomNotification();
            }
        }, 15000); // A cada 15 segundos exatos
    }

    // Iniciar apenas se houver produtos reais
    if (storeProducts.length > 0) {
        startNotificationSystem();
    }

    // Limpar intervalos quando a página for fechada
    window.addEventListener('beforeunload', () => {
        if (notificationTimeout) clearTimeout(notificationTimeout);
        if (notificationInterval) clearInterval(notificationInterval);
    });
});
</script>

<?php
include($virtualpath.'/_layout/rdp.php');
include($virtualpath.'/_layout/footer.php');
?>